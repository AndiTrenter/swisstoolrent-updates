<?php get_header(); ?>
<section class="str-section str-shell str-page-content">
	<?php while ( have_posts() ) : the_post(); ?><article <?php post_class(); ?>><header><h1><?php the_title(); ?></h1></header><?php the_content(); ?></article><?php endwhile; ?>
</section>
<?php get_footer(); ?>
