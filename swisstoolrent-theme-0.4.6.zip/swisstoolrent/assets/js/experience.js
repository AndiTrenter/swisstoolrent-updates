(function () {
  "use strict";

  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var sections = document.querySelectorAll(".str-section, .str-final-cta");
  if (!reduceMotion && "IntersectionObserver" in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    sections.forEach(function (section) {
      section.classList.add("str-reveal");
      observer.observe(section);
    });
  }

  var contactForm = document.querySelector("[data-contact-form]");
  if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
      event.preventDefault();
      contactForm.classList.add("is-sent");
      var status = contactForm.querySelector("[data-contact-status]");
      var submit = contactForm.querySelector("button[type=submit]");
      if (status) status.textContent = "Danke. Ihre Anfrage ist in der Vorschau vorgemerkt.";
      if (submit) submit.textContent = "Anfrage vorgemerkt";
    });
  }

  var marketSearch = document.querySelector("[data-market-search]");
  var marketCards = Array.prototype.slice.call(document.querySelectorAll("[data-listing]"));
  var marketCategory = document.querySelector("[data-market-category]");
  var marketCount = document.querySelector("[data-market-count]");
  var marketEmpty = document.querySelector("[data-market-empty]");
  function filterMarket() {
    var query = marketSearch ? (new FormData(marketSearch).get("q") || "").toString().toLowerCase().trim() : "";
    var category = marketCategory ? marketCategory.value : "all";
    var visible = 0;
    marketCards.forEach(function (card) {
      var matches = (!query || card.dataset.search.indexOf(query) !== -1) && (category === "all" || card.dataset.category === category);
      card.hidden = !matches;
      if (matches) visible += 1;
    });
    if (marketCount) marketCount.textContent = visible;
    if (marketEmpty) marketEmpty.hidden = visible !== 0;
  }
  if (marketSearch) marketSearch.addEventListener("submit", function (event) { event.preventDefault(); filterMarket(); });
  if (marketCategory) marketCategory.addEventListener("change", filterMarket);
  var dialog = document.querySelector("[data-listing-dialog]");
  var dialogTitle = dialog && dialog.querySelector("[data-dialog-title]");
  var dialogCopy = dialog && dialog.querySelector("[data-dialog-copy]");
  document.querySelectorAll("[data-listing-open]").forEach(function (button) {
    button.addEventListener("click", function () {
      var card = button.closest("[data-listing]");
      if (!dialog || !card) return;
      dialogTitle.textContent = card.querySelector("h3").textContent;
      dialogCopy.textContent = card.querySelector(".str-listing-body p").textContent;
      if (dialog.showModal) dialog.showModal();
    });
  });
  if (dialog) {
    dialog.querySelector("[data-listing-close]").addEventListener("click", function () { dialog.close(); });
    dialog.querySelector("[data-listing-request]").addEventListener("submit", function (event) {
      event.preventDefault();
      var status = dialog.querySelector("[data-dialog-status]");
      status.textContent = "Anfrage vorbereitet. Für die Übermittlung bitte einloggen oder registrieren.";
    });
  }

  var story = document.querySelector("[data-product-story]");
  if (!story) return;
  var frame = story.querySelector("[data-story-frame]");
  var count = story.querySelector("[data-story-count]");
  var title = story.querySelector("[data-story-title]");
  var copy = story.querySelector("[data-story-copy]");
  var toggle = story.querySelector("[data-story-toggle]");
  var buttons = Array.prototype.slice.call(story.querySelectorAll("[data-story-step]"));
  var scenes = [
    ["Passendes Werkzeug finden", "Suche und Filter führen zum einsatzbereiten Set in der Nähe."],
    ["Sofort anfragen", "Verfügbarkeit, Express, Abholung und Bedingungen sind vor der Anfrage klar."],
    ["Per QR übergeben", "Werkzeug, Zubehör, Zustand, Person und Zeitpunkt werden eindeutig verbunden."],
    ["Nachvollziehbar zurückgeben", "Soll und Ist werden verglichen; Abweichungen gehen strukturiert in den Support Hub."]
  ];
  var active = 0;
  var playing = !reduceMotion;
  var timer;

  function render(next) {
    active = next;
    frame.className = "str-comic-frame str-comic-step-" + active;
    count.textContent = "0" + (active + 1) + " / 04";
    title.textContent = scenes[active][0];
    copy.textContent = scenes[active][1];
    buttons.forEach(function (button, index) { button.classList.toggle("active", index === active); });
  }

  function schedule() {
    window.clearInterval(timer);
    if (playing) timer = window.setInterval(function () { render((active + 1) % scenes.length); }, 4200);
    toggle.textContent = playing ? "Ⅱ" : "▶";
    toggle.setAttribute("aria-label", playing ? "Animation pausieren" : "Animation abspielen");
  }

  buttons.forEach(function (button, index) {
    button.addEventListener("click", function () { render(index); playing = false; schedule(); });
  });
  toggle.addEventListener("click", function () { playing = !playing; schedule(); });
  schedule();
})();
