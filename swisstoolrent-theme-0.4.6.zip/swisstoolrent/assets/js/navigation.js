(() => {
  "use strict";
  const button = document.querySelector(".str-menu-toggle");
  const navigation = document.querySelector("#str-primary-nav");
  if (!button || !navigation) return;
  const close = () => {
    button.setAttribute("aria-expanded", "false");
    navigation.classList.remove("is-open");
  };
  button.addEventListener("click", () => {
    const open = button.getAttribute("aria-expanded") !== "true";
    button.setAttribute("aria-expanded", String(open));
    navigation.classList.toggle("is-open", open);
  });
  navigation.addEventListener("click", (event) => { if (event.target.closest("a")) close(); });
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") { close(); button.focus(); } });
  document.addEventListener("click", (event) => { if (!navigation.contains(event.target) && !button.contains(event.target)) close(); });
  window.addEventListener("resize", () => { if (window.innerWidth > 800) close(); });
})();
