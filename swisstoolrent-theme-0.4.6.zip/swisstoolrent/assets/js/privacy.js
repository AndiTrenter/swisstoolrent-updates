(() => {
  "use strict";
  const storageKey = "swisstoolrent.cookie-consent.v1";
  const existing = window.localStorage.getItem(storageKey);
  const panel = document.createElement("section");
  panel.className = "str-cookie-panel";
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-label", "Cookie-Einstellungen");
  panel.innerHTML = `<div><strong>Ihre Privatsphäre, klar erklärt.</strong><button type="button" aria-label="Schliessen">×</button></div><p>Diese Website nutzt notwendige Speicherungen für Anmeldung, Sicherheit und Ihre Auswahl. Optionale Analyse- oder Marketingdienste sind im Pilotbetrieb nicht aktiv.</p><a href="/cookie-richtlinie/">Details zur Cookie-Richtlinie</a><div class="str-cookie-actions"><button type="button" data-choice="necessary">Nur notwendige</button><button type="button" data-choice="all">Alle akzeptieren</button></div>`;
  const open = () => { if (!panel.isConnected) document.body.append(panel); panel.hidden = false; };
  const close = () => { panel.hidden = true; };
  panel.querySelector('[aria-label="Schliessen"]').addEventListener("click", close);
  panel.querySelectorAll("[data-choice]").forEach((button) => button.addEventListener("click", () => {
    window.localStorage.setItem(storageKey, JSON.stringify({ choice: button.dataset.choice, savedAt: new Date().toISOString() }));
    close();
  }));
  document.querySelectorAll("[data-str-cookie-settings]").forEach((button) => button.addEventListener("click", open));
  if (!existing) open();
})();
