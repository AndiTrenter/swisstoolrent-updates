<?php get_header(); ?>
<section class="str-section str-shell str-page-content">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?><article <?php post_class(); ?>><h1><?php the_title(); ?></h1><?php the_content(); ?></article><?php endwhile; else : ?><h1>Keine Inhalte gefunden</h1><?php endif; ?>
</section>
<?php get_footer(); ?>
