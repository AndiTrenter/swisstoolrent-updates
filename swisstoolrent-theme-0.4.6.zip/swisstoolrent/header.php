<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="str-skip" href="#main-content"><?php esc_html_e( 'Zum Inhalt springen', 'swisstoolrent' ); ?></a>
<header class="str-site-header">
	<div class="str-shell str-header-inner">
		<a class="str-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="SwissToolRent Startseite">
			<img class="str-brand-logo" src="<?php echo esc_url( str_theme_asset( 'images/swisstoolrent-logo.svg' ) ); ?>" alt="SwissToolRent">
			<span class="str-brand-claim"><small>Werkzeuge. Sicher geteilt.</small></span>
		</a>
		<button class="str-menu-toggle" type="button" aria-expanded="false" aria-controls="str-primary-nav"><span class="str-menu-icon" aria-hidden="true"><i></i><i></i><i></i></span><span class="str-menu-label">Menü</span></button>
		<nav id="str-primary-nav" class="str-main-nav" aria-label="<?php esc_attr_e( 'Hauptnavigation', 'swisstoolrent' ); ?>">
				<a class="is-current" href="<?php echo esc_url( home_url( '/#mietplattform' ) ); ?>">Mietplattform</a>
				<a href="<?php echo esc_url( home_url( '/#werkzeug-management' ) ); ?>">Werkzeugverwaltung</a>
				<a href="<?php echo esc_url( home_url( '/#so-funktionierts' ) ); ?>">Wie funktioniert's?</a>
				<a href="<?php echo esc_url( home_url( '/support-hub/' ) ); ?>">Support Hub</a>
				<a class="str-nav-account" href="<?php echo esc_url( home_url( '/registrieren/' ) ); ?>">Einloggen / Registrieren</a>
		</nav>
		<a class="str-account-link" href="<?php echo esc_url( home_url( '/registrieren/' ) ); ?>" aria-label="Einloggen oder registrieren"><span aria-hidden="true">◎</span><strong>Einloggen</strong></a>
	</div>
</header>
<main id="main-content">
