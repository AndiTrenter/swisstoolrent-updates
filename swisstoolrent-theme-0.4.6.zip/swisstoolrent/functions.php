<?php
defined( 'ABSPATH' ) || exit;

define( 'STR_THEME_VERSION', '0.4.6' );

function str_theme_setup(): void {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 80, 'width' => 320, 'flex-height' => true, 'flex-width' => true ) );
	register_nav_menus( array( 'primary' => __( 'Hauptnavigation', 'swisstoolrent' ), 'footer' => __( 'Fussnavigation', 'swisstoolrent' ) ) );
}
add_action( 'after_setup_theme', 'str_theme_setup' );

function str_theme_assets(): void {
	wp_enqueue_style( 'swisstoolrent-theme', get_template_directory_uri() . '/assets/css/site.css', array(), STR_THEME_VERSION );
	wp_enqueue_style( 'swisstoolrent-sales', get_template_directory_uri() . '/assets/css/sales.css', array( 'swisstoolrent-theme' ), STR_THEME_VERSION );
	wp_enqueue_style( 'swisstoolrent-visuals', get_template_directory_uri() . '/assets/css/visuals.css', array( 'swisstoolrent-sales' ), STR_THEME_VERSION );
	wp_enqueue_style( 'swisstoolrent-navigation', get_template_directory_uri() . '/assets/css/navigation.css', array( 'swisstoolrent-visuals' ), STR_THEME_VERSION );
	wp_enqueue_style( 'swisstoolrent-polish', get_template_directory_uri() . '/assets/css/polish.css', array( 'swisstoolrent-navigation' ), STR_THEME_VERSION );
	wp_enqueue_style( 'swisstoolrent-experience', get_template_directory_uri() . '/assets/css/experience.css', array( 'swisstoolrent-polish' ), STR_THEME_VERSION );
	wp_enqueue_style( 'swisstoolrent-marketplace', get_template_directory_uri() . '/assets/css/marketplace.css', array( 'swisstoolrent-experience' ), STR_THEME_VERSION );
	wp_enqueue_script( 'swisstoolrent-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), STR_THEME_VERSION, true );
	wp_enqueue_script( 'swisstoolrent-privacy', get_template_directory_uri() . '/assets/js/privacy.js', array(), STR_THEME_VERSION, true );
	wp_enqueue_script( 'swisstoolrent-experience', get_template_directory_uri() . '/assets/js/experience.js', array(), STR_THEME_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'str_theme_assets' );

function str_theme_body_classes( array $classes ): array {
	$classes[] = is_user_logged_in() ? 'str-signed-in' : 'str-public';
	return $classes;
}
add_filter( 'body_class', 'str_theme_body_classes' );

function str_theme_portal_url(): string {
	return get_page_by_path( 'portal' ) ? home_url( '/portal/' ) : wp_login_url( home_url( '/portal/' ) );
}

function str_theme_asset( string $file ): string {
	return get_template_directory_uri() . '/assets/' . ltrim( $file, '/' );
}
