</main>
<footer class="str-site-footer">
	<div class="str-shell str-footer-grid">
		<section class="str-footer-brand"><img src="<?php echo esc_url( str_theme_asset( 'images/swisstoolrent-logo.svg' ) ); ?>" alt="SwissToolRent"><p>Die Schweizer Plattform für Werkzeugvermietung, digitale Tool Passports und nachvollziehbare Übergaben.</p><small>Pilotbetrieb · produktive Zahlungen und Vermietungen bleiben bis zur Freigabe deaktiviert.</small></section>
		<nav aria-label="Mieten"><strong>Mieten</strong><ul><li><a href="<?php echo esc_url( home_url( '/portal/?view=marketplace' ) ); ?>">Marktplatz öffnen</a></li><li><a href="<?php echo esc_url( home_url( '/portal/?view=bookings' ) ); ?>">Buchungen &amp; Anfragen</a></li><li><a href="<?php echo esc_url( home_url( '/mietbedingungen/' ) ); ?>">Mietbedingungen</a></li></ul></nav>
		<nav aria-label="Verwalten"><strong>Verwalten</strong><ul><li><a href="<?php echo esc_url( home_url( '/tool-hub/' ) ); ?>">Tool Hub</a></li><li><a href="<?php echo esc_url( home_url( '/portal/?view=settings' ) ); ?>">Übersicht &amp; Einstellungen</a></li><li><a href="<?php echo esc_url( home_url( '/registrieren/' ) ); ?>">Konto &amp; Abo</a></li></ul></nav>
		<nav aria-label="Vorgänge"><strong>Vorgänge</strong><ul><li><a href="<?php echo esc_url( home_url( '/portal/?view=communications' ) ); ?>">Nachrichten</a></li><li><a href="<?php echo esc_url( home_url( '/support-hub/' ) ); ?>">Support Hub</a></li><li><a href="<?php echo esc_url( home_url( '/prozess-studio/' ) ); ?>">Prozess Studio</a></li><li><a href="<?php echo esc_url( home_url( '/hilfe/' ) ); ?>">Hilfe &amp; FAQ</a></li></ul></nav>
		<nav aria-label="Über SwissToolRent"><strong>Über uns</strong><ul><li><a href="<?php echo esc_url( home_url( '/#ueber-uns' ) ); ?>">Über SwissToolRent</a></li><li><a href="<?php echo esc_url( home_url( '/#kontakt' ) ); ?>">Kontaktformular</a></li><li><a href="<?php echo esc_url( home_url( '/impressum/' ) ); ?>">Impressum</a></li></ul></nav>
		<nav aria-label="Vertrauen und Recht"><strong>Vertrauen &amp; Recht</strong><ul><li><a href="<?php echo esc_url( home_url( '/plattformrichtlinien/' ) ); ?>">Plattformrichtlinien</a></li><li><a href="<?php echo esc_url( home_url( '/sicherheit/' ) ); ?>">Sicherheit</a></li><li><a href="<?php echo esc_url( home_url( '/agb/' ) ); ?>">AGB</a></li><li><a href="<?php echo esc_url( home_url( '/datenschutz/' ) ); ?>">Datenschutz</a></li><li><button type="button" class="str-cookie-settings" data-str-cookie-settings>Cookie-Einstellungen</button></li></ul></nav>
	</div>
	<div class="str-shell str-footer-bottom"><span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> SwissToolRent</span><span class="str-webportal-version">WebPortal v<?php echo esc_html( STR_THEME_VERSION ); ?></span><span>Made for Switzerland</span><button type="button" class="str-cookie-settings" data-str-cookie-settings>Cookie-Einstellungen</button></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
