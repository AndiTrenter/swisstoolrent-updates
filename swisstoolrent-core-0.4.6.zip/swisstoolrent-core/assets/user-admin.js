(() => {
  "use strict";
  const root = document.querySelector(".str-user-admin");
  if (!root || !window.STRUserAdmin) return;
  const results = root.querySelector(".str-user-results"); const detail = root.querySelector(".str-user-detail"); const pagination = root.querySelector(".str-user-pagination");
  const search = root.querySelector("[data-user-search]"); const state = root.querySelector("[data-user-state]"); const plan = root.querySelector("[data-user-plan]");
  let page = 1; let selected;
  const escapeHtml = (value) => String(value ?? "").replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
  const request = async (path = "", options = {}) => {
    const response = await fetch(`${STRUserAdmin.endpoint}${path}`, { credentials: "same-origin", ...options, headers: { "Content-Type": "application/json", "X-WP-Nonce": STRUserAdmin.nonce, ...(options.headers || {}) } });
    const data = await response.json(); if (!response.ok || data.code) throw new Error(data.message || data.code || "Anfrage fehlgeschlagen"); return data;
  };
  const statusLabel = { ACTIVE: "Aktiv", SUSPENDED: "Gesperrt", ARCHIVED: "Archiviert", DELETION_PENDING: "Gelöscht" };
  const planLabel = { FREE: "Kostenlos", MANAGEMENT_INTERNAL: "Tool Hub Intern", MANAGEMENT_MARKETPLACE: "Tool Hub Intern & Extern" };
  const openUser = (user) => {
    selected = user;
    detail.innerHTML = `<div class="str-user-detail-head"><div><small>BENUTZERDATENSATZ</small><h2>${escapeHtml(user.displayName)}</h2><p>${escapeHtml(user.email)}</p></div><span class="str-user-state is-${escapeHtml(user.accountState).toLowerCase()}">${escapeHtml(statusLabel[user.accountState] || user.accountState)}</span></div>
      <form data-user-form><input type="hidden" name="id" value="${escapeHtml(user.id)}"><label class="str-field"><span>Anzeigename</span><input name="displayName" value="${escapeHtml(user.displayName)}" required></label><label class="str-field"><span>E-Mail</span><input name="email" type="email" value="${escapeHtml(user.email)}" required></label>
      <div class="str-admin-grid"><label class="str-field"><span>Sprache</span><select name="locale">${["de-CH","fr-CH","it-CH","en"].map((v)=>`<option ${user.locale===v?"selected":""}>${v}</option>`).join("")}</select></label><label class="str-field"><span>Rolle</span><select name="organizationRole">${["CUSTOMER","ORG_ADMIN","TOOL_MANAGER","TEAM_LEAD","EMPLOYEE","FINANCE","MARKETPLACE_MANAGER","INVENTORY_AUDITOR"].map((v)=>`<option ${user.organizationRole===v?"selected":""}>${v}</option>`).join("")}</select></label></div>
      <label class="str-field"><span>Kontostatus</span><select name="accountState">${["ACTIVE","SUSPENDED","ARCHIVED"].map((v)=>`<option value="${v}" ${user.accountState===v?"selected":""}>${statusLabel[v]}</option>`).join("")}</select><small>Gesperrte und archivierte Konten können keine aktive Sitzung mehr verwenden.</small></label>
      <label class="str-field"><span>Administrativer Abo-Zugang</span><select name="subscriptionPlanCode"><option value="">Kein manueller Zugang / Stripe gilt</option><option value="MANAGEMENT_INTERNAL" ${user.planCode==="MANAGEMENT_INTERNAL"?"selected":""}>Tool Hub Intern</option><option value="MANAGEMENT_MARKETPLACE" ${user.planCode==="MANAGEMENT_MARKETPLACE"?"selected":""}>Tool Hub Intern &amp; Extern</option></select><small>Ein Admin-Zugang überschreibt keine laufende Stripe-Buchung und erzeugt keine Zahlung.</small></label>
      <div class="str-user-facts"><span><b>Organisation</b>${escapeHtml(user.organizationName || "–")}</span><span><b>Abo-Quelle</b>${escapeHtml(user.subscriptionProvider || "–")}</span><span><b>Registriert</b>${escapeHtml(new Date(user.createdAt).toLocaleDateString("de-CH"))}</span></div>
      <p class="str-user-form-status" role="status"></p><div class="str-user-actions"><button type="submit" class="button button-primary">Änderungen speichern</button><button type="button" class="button str-user-delete">Konto löschen &amp; anonymisieren</button></div></form>`;
    detail.querySelector("form").addEventListener("submit", saveUser); detail.querySelector(".str-user-delete").addEventListener("click", deleteUser);
  };
  const load = async () => {
    results.innerHTML = "<p>Benutzer werden geladen …</p>";
    try {
      const params = new URLSearchParams({ page: String(page) }); if (search.value.trim()) params.set("q", search.value.trim()); if (state.value) params.set("state", state.value); if (plan.value) params.set("plan", plan.value);
      const data = await request(`?${params}`);
      results.innerHTML = data.users.length ? data.users.map((user) => `<button type="button" class="str-user-row" data-user-id="${escapeHtml(user.id)}"><span class="str-user-avatar">${escapeHtml((user.displayName || user.email).slice(0,1).toUpperCase())}</span><span><strong>${escapeHtml(user.displayName)}</strong><small>${escapeHtml(user.email)} · ${escapeHtml(user.organizationName || "Keine Organisation")}</small></span><span><b>${escapeHtml(planLabel[user.planCode] || user.planCode)}</b><small>${escapeHtml(statusLabel[user.accountState] || user.accountState)}</small></span></button>`).join("") : "<p>Keine Benutzer mit diesen Filtern gefunden.</p>";
      results.querySelectorAll("[data-user-id]").forEach((button) => button.addEventListener("click", () => openUser(data.users.find((user) => user.id === button.dataset.userId))));
      const p = data.pagination; pagination.innerHTML = `<button class="button" ${p.page<=1?"disabled":""} data-prev>← Zurück</button><span>Seite ${p.page} von ${p.pages} · ${p.total} Benutzer</span><button class="button" ${p.page>=p.pages?"disabled":""} data-next>Weiter →</button>`;
      pagination.querySelector("[data-prev]")?.addEventListener("click",()=>{page--;load();}); pagination.querySelector("[data-next]")?.addEventListener("click",()=>{page++;load();});
    } catch (error) { results.innerHTML = `<div class="notice notice-error"><p>${escapeHtml(error.message)}</p></div>`; }
  };
  const saveUser = async (event) => {
    event.preventDefault(); const form = event.currentTarget; const status = form.querySelector(".str-user-form-status"); const values = Object.fromEntries(new FormData(form));
    const payload = { displayName: values.displayName, email: values.email, locale: values.locale, organizationRole: values.organizationRole, accountState: values.accountState, subscriptionPlanCode: values.subscriptionPlanCode || null };
    status.textContent = "Änderungen werden gespeichert …";
    try { await request(`/${values.id}`, { method: "PATCH", body: JSON.stringify(payload) }); status.textContent = "Änderungen wurden gespeichert und protokolliert."; await load(); }
    catch (error) { status.textContent = error.message; }
  };
  const deleteUser = async () => {
    if (!selected) return;
    const check = window.prompt(`Diese Aktion entfernt die Anmeldung und anonymisiert persönliche Daten. Geben Sie zur Bestätigung die E-Mail-Adresse ein:\n${selected.email}`);
    if (check !== selected.email) return;
    const status = detail.querySelector(".str-user-form-status"); status.textContent = "Konto wird gesperrt und anonymisiert …";
    try { await request(`/${selected.id}`, { method: "DELETE", body: "{}" }); detail.innerHTML = "<h2>Konto gelöscht</h2><p>Die Anmeldung wurde entfernt, Mitgliedschaften wurden deaktiviert und persönliche Daten anonymisiert. Prüf- und Transaktionsnachweise bleiben erhalten.</p>"; await load(); }
    catch (error) { status.textContent = error.message; }
  };
  root.querySelector("[data-user-refresh]").addEventListener("click",()=>{page=1;load();}); search.addEventListener("keydown",(event)=>{if(event.key==="Enter"){event.preventDefault();page=1;load();}}); load();
})();
