(() => {
  "use strict";
  const host = document.querySelector(".str-google-auth");
  if (!host) return;
  const status = document.querySelector(".str-auth-status");
  const say = (message, isError = false) => {
    if (!status) return;
    status.textContent = message;
    status.classList.toggle("is-error", isError);
  };
  const outcome = new URLSearchParams(window.location.search).get("google");
  if (outcome === "abgebrochen") say("Google-Anmeldung wurde abgebrochen.", true);
  if (outcome === "fehlgeschlagen") say("Google-Anmeldung konnte nicht abgeschlossen werden. Bitte versuchen Sie es erneut.", true);

  const start = async () => {
    say("Google-Anmeldung wird vorbereitet …");
    const nonceResponse = await fetch(host.dataset.nonceUrl, { credentials: "include", cache: "no-store" });
    const nonce = await nonceResponse.json().catch(() => ({}));
    if (!nonceResponse.ok || !nonce.nonce || !nonce.nonceTicket) throw new Error("Der sichere Anmeldevorgang konnte nicht vorbereitet werden.");
    if (!window.google?.accounts?.id) {
      say("Google Identity konnte nicht geladen werden. Bitte laden Sie die Seite neu.", true);
      return;
    }
    window.google.accounts.id.initialize({
      client_id: host.dataset.clientId,
      nonce: nonce.nonce,
      use_fedcm_for_prompt: true,
      callback: async (googleResponse) => {
        try {
          say("Google-Konto wird sicher verbunden …");
          const response = await fetch(host.dataset.sessionUrl, {
            method: "POST",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ credential: googleResponse.credential, nonceTicket: nonce.nonceTicket }),
          });
          const result = await response.json().catch(() => ({}));
          if (!response.ok || !result.authenticated) throw new Error(result.message || "Google-Anmeldung konnte nicht abgeschlossen werden.");
          say("Anmeldung erfolgreich. Portal wird geöffnet …");
          window.location.assign(host.dataset.portalUrl);
        } catch (error) {
          say(error?.message || "Google-Anmeldung konnte nicht abgeschlossen werden.", true);
        }
      },
    });
    host.replaceChildren();
    window.google.accounts.id.renderButton(host, {
      type: "standard",
      theme: "outline",
      size: "large",
      text: "continue_with",
      shape: "rectangular",
      logo_alignment: "left",
      width: Math.min(400, Math.max(260, host.clientWidth || 360)),
    });
    say("");
  };

  if (window.google?.accounts?.id) start().catch((error) => say(error.message, true));
  else window.addEventListener("load", () => start().catch((error) => say(error.message, true)), { once: true });
})();

(() => {
  "use strict";
  const buttons = document.querySelectorAll(".str-checkout-button");
  if (!buttons.length) return;
  const status = document.querySelector(".str-checkout-status");
  const say = (message) => { if (status) status.textContent = message; };
  buttons.forEach((button) => button.addEventListener("click", async () => {
    buttons.forEach((entry) => { entry.disabled = true; });
    say("Stripe-Testcheckout wird vorbereitet …");
    try {
      const response = await fetch("/wp-json/swisstoolrent/v1/checkout-session", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json", "X-WP-Nonce": window.STRPortal?.restNonce || "" },
        body: JSON.stringify({ planCode: button.dataset.plan, billingInterval: button.dataset.interval }),
      });
      const result = await response.json();
      if (!response.ok || !result.checkoutUrl) throw new Error(result?.message || "Stripe-Testcheckout konnte nicht gestartet werden.");
      window.location.assign(result.checkoutUrl);
    } catch (error) {
      say(error?.message || "Stripe-Testcheckout konnte nicht gestartet werden.");
      buttons.forEach((entry) => { entry.disabled = false; });
    }
  }));
})();
