(() => {
  "use strict";
  const host = document.querySelector(".str-support-hub");
  if (!host) return;
  const panels = [...host.querySelectorAll("[data-panel]")];
  const navButtons = [...host.querySelectorAll("[data-support-panel]")];
  const list = host.querySelector(".str-support-list");
  let stream;
  let detectedReference = "";

  const stopCamera = () => { stream?.getTracks().forEach((track) => track.stop()); stream = undefined; const video = host.querySelector("video"); if (video) video.srcObject = null; };
  const openPanel = (name) => {
    panels.forEach((panel) => panel.classList.toggle("is-active", panel.dataset.panel === name));
    navButtons.forEach((button) => button.classList.toggle("is-active", button.dataset.supportPanel === name));
    if (name !== "damage" && stream) stopCamera();
    host.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  navButtons.forEach((button) => button.addEventListener("click", () => openPanel(button.dataset.supportPanel)));
  host.querySelectorAll("[data-open-support]").forEach((button) => button.addEventListener("click", () => openPanel(button.dataset.openSupport)));

  const labels = { OPEN: "Offen", WAITING_FOR_CUSTOMER: "Rückmeldung ausstehend", IN_REVIEW: "In Prüfung", RESOLVED: "Gelöst", CLOSED: "Geschlossen" };
  const categoryLabels = { INVENTORY_DIFFERENCE: "Inventarabweichung", DAMAGE: "Schaden", FUNCTION: "Funktion", SHIPPING: "Versand", PAYMENT: "Zahlung & Kaution", OTHER: "Sonstiges" };
  const render = (cases) => {
    if (!list) return;
    list.replaceChildren();
    if (!cases.length) { const p = document.createElement("p"); p.textContent = "Noch keine Supportfälle vorhanden."; list.appendChild(p); return; }
    cases.forEach((entry) => {
      const article = document.createElement("article");
      const meta = document.createElement("small"); meta.textContent = `${categoryLabels[entry.category] || entry.category} · ${labels[entry.status] || entry.status} · ${String(entry.id).slice(0, 8)}`;
      const title = document.createElement("h3"); title.textContent = entry.title;
      const body = document.createElement("p"); body.textContent = entry.description;
      article.append(meta, title, body); list.appendChild(article);
    });
  };
  const load = async () => {
    const response = await fetch(host.dataset.supportUrl, { credentials: "same-origin", headers: { "X-WP-Nonce": window.STRPortal?.restNonce || "" } });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Support Hub konnte nicht geladen werden.");
    render(result.cases || []);
  };
  host.querySelectorAll(".str-support-form").forEach((form) => form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = form.querySelector("button[type=submit]"); const status = form.querySelector(".str-support-status");
    button.disabled = true; status.textContent = "Supportfall wird gespeichert …";
    try {
      const data = Object.fromEntries(new FormData(form).entries());
      const context = [data.area && `Bereich: ${data.area}`, data.referenceType && `Bezug: ${data.referenceType}`, detectedReference && `Werkzeug-ID: ${detectedReference}`].filter(Boolean).join("\n");
      data.description = `${context}${context ? "\n\n" : ""}${data.description}`;
      const response = await fetch(host.dataset.supportUrl, { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", "X-WP-Nonce": window.STRPortal?.restNonce || "" }, body: JSON.stringify(data) });
      const result = await response.json();
      if (!response.ok || !result.saved) throw new Error(result.message || "Supportfall konnte nicht gespeichert werden.");
      form.reset(); detectedReference = ""; status.textContent = "Supportfall wurde angelegt und eindeutig protokolliert."; await load();
    } catch (error) { status.textContent = error?.message || "Supportfall konnte nicht gespeichert werden."; }
    finally { button.disabled = false; }
  }));

  const video = host.querySelector(".str-qr-camera video"); const qrStatus = host.querySelector(".str-qr-status"); const referenceInput = host.querySelector(".str-tool-reference"); const detected = host.querySelector(".str-detected-tool");
  const setReference = (value) => { detectedReference = String(value || "").trim(); detected.textContent = detectedReference || "Noch keines zugeordnet"; if (detectedReference) qrStatus.textContent = "QR-/Tool-ID erkannt und bereit zur Übernahme."; };
  const scanVideo = async () => {
    if (!("BarcodeDetector" in window)) { qrStatus.textContent = "Live-QR-Erkennung wird von diesem Browser nicht unterstützt. Nutzen Sie Bildauswahl oder manuelle Eingabe."; return; }
    const detector = new BarcodeDetector({ formats: ["qr_code"] });
    const tick = async () => { if (!stream || video.readyState < 2) return; try { const codes = await detector.detect(video); if (codes[0]?.rawValue) { setReference(codes[0].rawValue); stopCamera(); return; } } catch (_) {} if (stream) requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  };
  host.querySelector(".str-start-qr")?.addEventListener("click", async () => {
    stopCamera(); qrStatus.textContent = "Rückkamera wird gestartet …";
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false }); video.srcObject = stream; await video.play(); qrStatus.textContent = "Halten Sie den QR-Code ruhig in den markierten Bereich."; scanVideo(); }
    catch (_) { qrStatus.textContent = "Kamera konnte nicht gestartet werden. Erlauben Sie den Zugriff oder nutzen Sie Bildauswahl bzw. manuelle Eingabe."; }
  });
  host.querySelector(".str-confirm-tool")?.addEventListener("click", () => setReference(referenceInput.value));
  host.querySelector(".str-upload-button input")?.addEventListener("change", async (event) => {
    const file = event.target.files?.[0]; if (!file) return;
    if (!("BarcodeDetector" in window)) { qrStatus.textContent = "Ihr Browser kann das Bild nicht automatisch lesen. Bitte geben Sie die ID manuell ein."; return; }
    qrStatus.textContent = "QR-Bild wird analysiert …";
    try { const bitmap = await createImageBitmap(file); const codes = await new BarcodeDetector({ formats: ["qr_code"] }).detect(bitmap); bitmap.close(); if (!codes[0]?.rawValue) throw new Error(); setReference(codes[0].rawValue); }
    catch (_) { qrStatus.textContent = "Kein lesbarer QR-Code erkannt. Nutzen Sie ein schärferes Bild oder die manuelle Eingabe."; }
  });

  const manual = {
    start: { title: "Erste Schritte", intro: "Vom kostenlosen Google-Konto bis zum ersten verwalteten Werkzeug.", steps: [["1", "Mit Google anmelden", "Öffnen Sie Registrieren und bestätigen Sie Ihr Google-Konto. SwissToolRent erhält kein Passwort."], ["2", "Aktive Ansicht prüfen", "Im Portal sehen Sie deutlich, ob Sie als Kunde, Firmenadmin oder WebPortal-Admin arbeiten."], ["3", "Tool Hub öffnen", "Dort verwalten Sie Werkzeuge, Tool Passports, Standorte, Ausgaben und Rückgaben."]] },
    tool: { title: "Werkzeug anlegen", intro: "Der geführte Ablauf sammelt Identität, Herstellerdaten und vollständigen Lieferumfang.", steps: [["1", "Werkzeug fotografieren", "Übersicht und Typenschild scharf aufnehmen; die Rückkamera wird bevorzugt."], ["2", "Erkennung kontrollieren", "Hersteller, Modell, Seriennummer und offizielle technische Daten prüfen oder korrigieren."], ["3", "Inventar ausbreiten", "Koffer öffnen, alle Teile sichtbar auslegen und die angeforderten Perspektiven fotografieren."], ["4", "Versand und Kaution", "Verpackung, Gewicht, Masse, Lieferart, Preisvorschlag und Kaution freigeben."], ["5", "QR befestigen", "QR-Code drucken, nach Vorgabe befestigen und Lesbarkeit bestätigen lassen."]] },
    rental: { title: "Vermieten und versenden", intro: "Nur einsatzbereite, vollständige Werkzeuge werden freigegeben.", steps: [["1", "Einsatzbereitschaft", "Funktion, Sicherheitszustand und erforderliches Standardzubehör bestätigen."], ["2", "Mietbedingungen", "Preis, Kaution, Verfügbarkeit, Übergabe und Stornierung festlegen."], ["3", "Versand", "Nur bei Versand: Verpackungsklasse, Masse, Gewicht, Dienstleister und Preise prüfen."], ["4", "Rückgabe", "Soll-Inventar und Rückgabefotos vergleichen; Abweichungen gehen in den Support Hub."]] },
    company: { title: "Firma, Mitarbeitende und Rollen", intro: "Jede Person sieht nur die Funktionen, für die sie berechtigt wurde.", steps: [["1", "Firma einrichten", "Firmenprofil, Orte, Fahrzeuge sowie Kautions- und Versandvorgaben pflegen."], ["2", "Mitarbeitende", "Person einladen und Rolle passend zur Aufgabe vergeben."], ["3", "Rechte prüfen", "Bearbeiten, Freigeben, Vermieten, Support und Administration getrennt berechtigen."]] },
    support: { title: "Support und Schadenfälle", intro: "Beweise, Kommunikation und Entscheidungen bleiben am Vorgang.", steps: [["1", "Werkzeug scannen", "Beim Schadenfall zuerst den QR-Code scannen oder die Tool-ID eingeben."], ["2", "Fall einreichen", "Kategorie, Dringlichkeit, Beschreibung und relevante Medien vollständig erfassen."], ["3", "Status verfolgen", "Unter Meine Fälle sehen Sie Fallnummer, Bearbeitungsstand und angeforderte Rückmeldungen."]] },
    process: { title: "Prozess Studio", intro: "WebPortal-Admins gestalten dort Portalabläufe und Freigabelogik.", steps: [["1", "Ziel beschreiben", "Im Prozess-Chat in Alltagssprache erklären, was der Ablauf erreichen soll."], ["2", "Vorschlag prüfen", "Vorausgefüllte Schritte, Rollen, Datenfelder, Ausnahmen und Medienanforderungen kontrollieren."], ["3", "Konflikte simulieren", "Vor der Freigabe Überschneidungen mit vorhandenen Prozessen prüfen."], ["4", "Freigeben", "Nur berechtigte Rollen dürfen eine geprüfte Version veröffentlichen."]] }
  };
  const content = host.querySelector(".str-manual-content");
  const renderManual = (key) => { const topic = manual[key] || manual.start; content.innerHTML = `<small>SCHRITT FÜR SCHRITT</small><h3>${topic.title}</h3><p>${topic.intro}</p><ol>${topic.steps.map(([n,t,d]) => `<li><b>${n}</b><div><strong>${t}</strong><p>${d}</p></div></li>`).join("")}</ol>`; host.querySelectorAll("[data-manual-topic]").forEach((button) => button.classList.toggle("is-active", button.dataset.manualTopic === key)); };
  host.querySelectorAll("[data-manual-topic]").forEach((button) => button.addEventListener("click", () => renderManual(button.dataset.manualTopic)));
  host.querySelector(".str-manual-search")?.addEventListener("input", (event) => { const query = event.target.value.toLowerCase().trim(); if (!query) { renderManual("start"); return; } const match = Object.entries(manual).find(([, topic]) => `${topic.title} ${topic.intro} ${topic.steps.flat().join(" ")}`.toLowerCase().includes(query)); if (match) renderManual(match[0]); else content.innerHTML = `<div class="str-manual-empty"><strong>Keine direkte Anleitung gefunden.</strong><p>Erstellen Sie einen Supportfall – Ihre Suche wird als Kontext übernommen.</p><button type="button" class="str-button" data-manual-contact>Support kontaktieren</button></div>`; });
  content?.addEventListener("click", (event) => { if (event.target.closest("[data-manual-contact]")) openPanel("contact"); });
  renderManual("start"); load().catch((error) => { if (list) list.textContent = error?.message || "Support Hub konnte nicht geladen werden."; }); window.addEventListener("pagehide", stopCamera);
})();
