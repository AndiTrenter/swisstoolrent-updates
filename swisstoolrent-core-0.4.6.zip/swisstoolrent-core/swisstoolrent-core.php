<?php
/**
 * Plugin Name:       SwissToolRent Core
 * Plugin URI:        https://www.swisstoolrent.ch/
 * Description:       Verbindet WordPress sicher mit dem SwissToolRent-Backend und stellt Portal, Rollen, Setup und Systemstatus bereit.
 * Version:           0.4.6
 * Requires at least: 6.6
 * Requires PHP:      8.1
 * Author:            SwissToolRent
 * Author URI:        https://www.swisstoolrent.ch/
 * License:           GPL-2.0-or-later
 * Update URI:        https://www.swisstoolrent.ch/updates/swisstoolrent-core/
 * Text Domain:       swisstoolrent-core
 */

defined( 'ABSPATH' ) || exit;

define( 'STR_CORE_VERSION', '0.4.6' );
define( 'STR_CORE_FILE', __FILE__ );
define( 'STR_CORE_DIR', plugin_dir_path( __FILE__ ) );
define( 'STR_CORE_URL', plugin_dir_url( __FILE__ ) );

final class SwissToolRent_Core {
	private const OPTION = 'str_core_settings';
	private const SECRET_OPTION = 'str_core_api_secret';
	private const DEFAULT_API = 'https://api.swisstoolrent.ch/v1';
	private const DEFAULT_UPDATE_MANIFEST = 'https://www.swisstoolrent.ch/updates/swisstoolrent-core.json';
	private const DEFAULT_THEME_UPDATE_MANIFEST = 'https://www.swisstoolrent.ch/updates/swisstoolrent-theme.json';

	public static function boot(): void {
		add_action( 'init', array( self::class, 'migrate_labels' ), 5 );
		add_action( 'init', array( self::class, 'register_shortcodes' ) );
		add_action( 'init', array( self::class, 'ensure_pages' ), 20 );
		add_action( 'admin_menu', array( self::class, 'admin_menu' ) );
		add_action( 'admin_init', array( self::class, 'register_settings' ) );
		add_action( 'admin_post_str_save_settings', array( self::class, 'save_settings' ) );
		add_action( 'admin_post_str_test_connection', array( self::class, 'test_connection' ) );
		add_action( 'admin_post_str_save_gate', array( self::class, 'save_gate' ) );
		add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue_assets' ) );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue_admin_assets' ) );
		add_action( 'rest_api_init', array( self::class, 'register_rest_routes' ) );
		add_action( 'admin_init', array( self::class, 'protect_customer_admin' ), 30 );
		add_filter( 'show_admin_bar', array( self::class, 'show_admin_bar' ) );
		add_filter( 'pre_set_site_transient_update_plugins', array( self::class, 'check_plugin_update' ) );
		add_filter( 'pre_set_site_transient_update_themes', array( self::class, 'check_theme_update' ) );
		add_filter( 'auto_update_plugin', array( self::class, 'force_core_auto_update' ), 10, 2 );
		add_filter( 'auto_update_theme', array( self::class, 'force_theme_auto_update' ), 10, 2 );
		add_filter( 'wp_mail', array( self::class, 'brand_wp_mail' ) );
		add_filter( 'wp_mail_content_type', array( self::class, 'mail_content_type' ) );
		add_filter( 'wp_mail_from_name', array( self::class, 'mail_from_name' ) );
		add_filter( 'wp_mail_from', array( self::class, 'mail_from_address' ) );
		add_filter( 'password_change_email', array( self::class, 'password_change_email' ), 10, 3 );
		add_filter( 'email_change_email', array( self::class, 'email_change_email' ), 10, 3 );
		add_filter( 'retrieve_password_message', array( self::class, 'retrieve_password_message' ), 10, 4 );
		add_filter( 'retrieve_password_title', array( self::class, 'retrieve_password_title' ), 10, 3 );
		add_filter( 'wp_new_user_notification_email', array( self::class, 'new_user_notification_email' ), 10, 3 );
		add_action( 'login_enqueue_scripts', array( self::class, 'login_assets' ) );
		add_filter( 'login_headerurl', array( self::class, 'login_header_url' ) );
		add_filter( 'login_headertext', array( self::class, 'login_header_text' ) );
		add_filter( 'login_message', array( self::class, 'login_message' ) );
		add_action( 'wp_head', array( self::class, 'favicon_links' ), 1 );
		add_action( 'login_head', array( self::class, 'favicon_links' ), 1 );
		add_action( 'admin_head', array( self::class, 'favicon_links' ), 1 );
		add_filter( 'cron_schedules', array( self::class, 'cron_schedules' ) );
		add_action( 'init', array( self::class, 'ensure_update_schedule' ), 30 );
		add_action( 'str_release_poll', array( self::class, 'poll_releases' ) );
	}

	public static function migrate_labels(): void {
		if ( get_option( 'str_core_label_version' ) === STR_CORE_VERSION ) return;
		$settings = get_option( self::OPTION, array() );
		if ( is_array( $settings ) && isset( $settings['subscription_plans'] ) ) {
			if ( isset( $settings['subscription_plans']['internal']['name'] ) ) $settings['subscription_plans']['internal']['name'] = 'Tool Hub Intern';
			if ( isset( $settings['subscription_plans']['external']['name'] ) ) $settings['subscription_plans']['external']['name'] = 'Tool Hub Intern & Extern';
			update_option( self::OPTION, $settings, false );
		}
		update_option( 'str_core_label_version', STR_CORE_VERSION, false );
	}

	public static function activate(): void {
		$roles = array(
			'swisstoolrent_customer' => array( 'read' => true, 'str_access_portal' => true ),
			'swisstoolrent_business_admin' => array( 'read' => true, 'str_access_portal' => true, 'str_manage_company' => true ),
			'swisstoolrent_portal_admin' => array( 'read' => true, 'str_access_portal' => true, 'str_manage_company' => true, 'str_manage_platform' => true ),
		);
		foreach ( $roles as $slug => $caps ) {
			$role = get_role( $slug );
			if ( ! $role ) {
				add_role( $slug, self::role_label( $slug ), $caps );
				continue;
			}
			foreach ( $caps as $cap => $allowed ) {
				if ( $allowed ) {
					$role->add_cap( $cap );
				}
			}
		}
		$administrator = get_role( 'administrator' );
		if ( $administrator ) {
			foreach ( array( 'str_access_portal', 'str_manage_company', 'str_manage_platform' ) as $cap ) {
				$administrator->add_cap( $cap );
			}
		}
		if ( ! get_option( self::OPTION ) ) {
			add_option( self::OPTION, self::defaults(), '', false );
		}
		self::ensure_pages();
		self::ensure_update_schedule();
		flush_rewrite_rules();
	}

	public static function cron_schedules( array $schedules ): array {
		$schedules['str_fifteen_minutes'] = array( 'interval' => 900, 'display' => 'Alle 15 Minuten' );
		return $schedules;
	}

	public static function ensure_update_schedule(): void {
		$plugins = (array) get_site_option( 'auto_update_plugins', array() );
		$core = plugin_basename( STR_CORE_FILE );
		if ( ! in_array( $core, $plugins, true ) ) {
			$plugins[] = $core;
			update_site_option( 'auto_update_plugins', array_values( array_unique( $plugins ) ) );
		}
		$themes = (array) get_site_option( 'auto_update_themes', array() );
		if ( ! in_array( 'swisstoolrent', $themes, true ) ) {
			$themes[] = 'swisstoolrent';
			update_site_option( 'auto_update_themes', array_values( array_unique( $themes ) ) );
		}
		if ( ! wp_next_scheduled( 'str_release_poll' ) ) wp_schedule_event( time() + 300, 'str_fifteen_minutes', 'str_release_poll' );
	}

	public static function poll_releases(): void {
		delete_site_transient( 'update_plugins' );
		delete_site_transient( 'update_themes' );
		if ( ! function_exists( 'wp_update_plugins' ) ) require_once ABSPATH . 'wp-admin/includes/update.php';
		wp_update_plugins();
		wp_update_themes();
		if ( function_exists( 'wp_maybe_auto_update' ) ) wp_maybe_auto_update();
	}

	public static function force_core_auto_update( $update, $item ) {
		return isset( $item->plugin ) && plugin_basename( STR_CORE_FILE ) === $item->plugin ? true : $update;
	}

	public static function force_theme_auto_update( $update, $item ) {
		$theme = is_object( $item ) ? ( $item->theme ?? $item->slug ?? '' ) : '';
		return 'swisstoolrent' === $theme ? true : $update;
	}

	public static function deactivate(): void {
		wp_clear_scheduled_hook( 'str_release_poll' );
	}

	private static function role_label( string $role ): string {
		$labels = array(
			'swisstoolrent_customer' => 'SwissToolRent Kunde',
			'swisstoolrent_business_admin' => 'SwissToolRent Firmenadmin',
			'swisstoolrent_portal_admin' => 'SwissToolRent WebPortal-Admin',
		);
		return $labels[ $role ] ?? $role;
	}

	private static function defaults(): array {
		return array(
			'platform_name' => 'SwissToolRent',
			'operator_name' => '',
			'contact_email' => get_option( 'admin_email' ),
			'api_base_url' => self::DEFAULT_API,
			'api_client_id' => '',
			'google_client_id' => '',
			'update_manifest_url' => self::DEFAULT_UPDATE_MANIFEST,
			'theme_update_manifest_url' => self::DEFAULT_THEME_UPDATE_MANIFEST,
			'locales' => array( 'de-CH', 'fr-CH', 'it-CH', 'en' ),
			'gates' => array(
				'legal' => 'OPEN',
				'finance' => 'OPEN',
				'privacy' => 'IN_REVIEW',
				'operations' => 'IN_REVIEW',
			),
			'configured' => false,
			'subscription_plans' => array(
				'internal' => array( 'name' => 'Tool Hub Intern', 'monthly' => 29, 'yearly' => 290, 'trial_days' => 14, 'max_tools' => 100, 'max_members' => 5, 'status' => 'IN_REVIEW' ),
				'external' => array( 'name' => 'Tool Hub Intern & Extern', 'monthly' => 49, 'yearly' => 490, 'trial_days' => 14, 'max_tools' => 500, 'max_members' => 15, 'status' => 'IN_REVIEW' ),
			),
		);
	}

	private static function settings(): array {
		return wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
	}

	private static function logo_url(): string {
		return get_theme_file_uri( 'assets/images/swisstoolrent-logo.svg' );
	}

	private static function mark_url(): string {
		return get_theme_file_uri( 'assets/images/swisstoolrent-mark.svg' );
	}

	private static function email_processes(): array {
		return array(
			'identity.google_started' => array( 'phase' => 'Konto', 'trigger' => 'Google-Anmeldung gestartet oder Konto neu erstellt', 'audience' => 'Nutzer', 'subject' => 'Ihr SwissToolRent Zugang ist bereit', 'action' => 'Portal öffnen', 'priority' => 'P2', 'body' => 'Bestätigt den sicheren Zugang und führt zurück ins Portal.' ),
			'identity.password_changed' => array( 'phase' => 'Konto', 'trigger' => 'WordPress-Passwort geändert', 'audience' => 'Nutzer', 'subject' => 'Passwort geändert', 'action' => 'Änderung prüfen', 'priority' => 'P1', 'body' => 'Sicherheitsbestätigung mit Hinweis auf Support, falls die Änderung nicht gewollt war.' ),
			'identity.email_changed' => array( 'phase' => 'Konto', 'trigger' => 'E-Mail-Adresse geändert', 'audience' => 'Nutzer', 'subject' => 'E-Mail-Adresse geändert', 'action' => 'Konto prüfen', 'priority' => 'P1', 'body' => 'Sicherheitsbestätigung mit alter und neuer Adresse, soweit verfügbar.' ),
			'identity.reset_requested' => array( 'phase' => 'Konto', 'trigger' => 'Passwort-Zurücksetzen angefordert', 'audience' => 'Nutzer', 'subject' => 'Passwort zurücksetzen', 'action' => 'Passwort neu setzen', 'priority' => 'P1', 'body' => 'Kurzlebiger Link; kein Passwort im Klartext.' ),
			'tool.onboarding_started' => array( 'phase' => 'Tool Hub', 'trigger' => 'Werkzeug-Onboarding gestartet', 'audience' => 'Erfasser, Firmenadmin', 'subject' => 'Werkzeug-Onboarding gestartet', 'action' => 'Tool Passport vervollständigen', 'priority' => 'P3', 'body' => 'Benannte nächste Schritte für Foto, Typenschild, Lieferumfang und Einsatzbereitschaft.' ),
			'tool.identity_review' => array( 'phase' => 'Tool Hub', 'trigger' => 'Identität unsicher oder Quelle widersprüchlich', 'audience' => 'Firmenadmin', 'subject' => 'Werkzeugangaben prüfen', 'action' => 'Angaben prüfen', 'priority' => 'P2', 'body' => 'Portal bleibt Faktenquelle; E-Mail zeigt nur Zusammenfassung und Link.' ),
			'tool.readiness_blocked' => array( 'phase' => 'Freigabe', 'trigger' => 'Einsatzbereitschaft, Zubehör oder QR blockiert', 'audience' => 'Firmenadmin', 'subject' => 'Freigabe blockiert', 'action' => 'Blocker lösen', 'priority' => 'P2', 'body' => 'Blocker, Verantwortlichkeit und nächste Prüfung transparent aufführen.' ),
			'listing.published' => array( 'phase' => 'Marktplatz', 'trigger' => 'Werkzeug intern oder extern veröffentlicht', 'audience' => 'Vermieter, Firmenadmin', 'subject' => 'Werkzeug veröffentlicht', 'action' => 'Inserat ansehen', 'priority' => 'P3', 'body' => 'Veröffentlichte Reichweite, Preisstatus und Stop-Gate-Hinweise.' ),
			'booking.requested' => array( 'phase' => 'Buchung', 'trigger' => 'Mietanfrage eingegangen', 'audience' => 'Vermieter', 'subject' => 'Neue Mietanfrage', 'action' => 'Anfrage bearbeiten', 'priority' => 'P1', 'body' => 'Zeitfenster, Werkzeug, Abhol-/Versandart und Antwortfrist.' ),
			'booking.confirmed' => array( 'phase' => 'Buchung', 'trigger' => 'Buchung bestätigt', 'audience' => 'Mieter, Vermieter', 'subject' => 'Buchung bestätigt', 'action' => 'Details öffnen', 'priority' => 'P1', 'body' => 'Übergabe, Rückgabe, Lieferumfang, Kaution und Supportpfad.' ),
			'booking.cancelled' => array( 'phase' => 'Buchung', 'trigger' => 'Buchung abgebrochen oder storniert', 'audience' => 'Mieter, Vermieter', 'subject' => 'Buchung storniert', 'action' => 'Vorgang prüfen', 'priority' => 'P2', 'body' => 'Grund, nächster Status und Hinweis auf offene Zahlungen nur bei verifizierter Quelle.' ),
			'handover.due' => array( 'phase' => 'Übergabe', 'trigger' => 'Übergabe steht an', 'audience' => 'Mieter, Vermieter', 'subject' => 'Übergabe vorbereiten', 'action' => 'Checkliste öffnen', 'priority' => 'P2', 'body' => 'QR, Fotos, Lieferumfang und Sicherheitscheck.' ),
			'return.due' => array( 'phase' => 'Rückgabe', 'trigger' => 'Rückgabe steht an oder ist überfällig', 'audience' => 'Mieter, Vermieter', 'subject' => 'Rückgabe fällig', 'action' => 'Rückgabe dokumentieren', 'priority' => 'P1', 'body' => 'Frist, Zustandserfassung und Portalpfad.' ),
			'shipping.ready' => array( 'phase' => 'Versand', 'trigger' => 'Verpackung und Versandbereitschaft bestätigt', 'audience' => 'Versender, Mieter', 'subject' => 'Versand vorbereitet', 'action' => 'Versandstatus öffnen', 'priority' => 'P2', 'body' => 'Tracking nur aus bestätigtem Providerfluss, keine erfundenen Tarife.' ),
			'payment.checkout_started' => array( 'phase' => 'Zahlung', 'trigger' => 'Checkout gestartet oder abgebrochen', 'audience' => 'Zahler', 'subject' => 'Zahlung im Portal fortsetzen', 'action' => 'Checkout öffnen', 'priority' => 'P1', 'body' => 'Nur geprüfte Zahlungslinks, Testmodus klar kennzeichnen.' ),
			'payment.succeeded' => array( 'phase' => 'Zahlung', 'trigger' => 'Signierter Webhook bestätigt Zahlung', 'audience' => 'Zahler, Vermieter', 'subject' => 'Zahlung bestätigt', 'action' => 'Beleg öffnen', 'priority' => 'P1', 'body' => 'Betrag, Status und Beleg ausschliesslich aus Ledger/Providerdaten.' ),
			'deposit.hold_created' => array( 'phase' => 'Kaution', 'trigger' => 'Kaution autorisiert', 'audience' => 'Mieter, Vermieter', 'subject' => 'Kaution autorisiert', 'action' => 'Kautionsstatus prüfen', 'priority' => 'P1', 'body' => 'Kautionsstatus, Gültigkeit und Einsprachepfad.' ),
			'deposit.dispute_opened' => array( 'phase' => 'Kaution', 'trigger' => 'Schaden, Verlust oder Inventarabweichung', 'audience' => 'Mieter, Vermieter, Support', 'subject' => 'Klärung im Support Hub eröffnet', 'action' => 'Fall bearbeiten', 'priority' => 'P1', 'body' => 'Keine automatische Belastung bei strittigen Fällen; Nachweise im Portal.' ),
			'support.created' => array( 'phase' => 'Support', 'trigger' => 'Supportfall angelegt', 'audience' => 'Anfragender, Support', 'subject' => 'Supportfall eröffnet', 'action' => 'Supportfall öffnen', 'priority' => 'P1', 'body' => 'Fallnummer, Kategorie, Priorität und nächster Bearbeitungsschritt.' ),
			'support.updated' => array( 'phase' => 'Support', 'trigger' => 'Antwort, Statuswechsel oder Lösung', 'audience' => 'Beteiligte', 'subject' => 'Supportfall aktualisiert', 'action' => 'Antwort lesen', 'priority' => 'P2', 'body' => 'Portal bleibt Verlaufsspeicher; E-Mail enthält nur Entscheidungszusammenfassung.' ),
			'admin.gate_changed' => array( 'phase' => 'Administration', 'trigger' => 'Freigabe- oder Stop-Gate-Status geändert', 'audience' => 'WebPortal-Admin', 'subject' => 'Freigabestatus geändert', 'action' => 'Freigaben prüfen', 'priority' => 'P1', 'body' => 'Audit-Hinweis mit altem/neuem Status und Verantwortlichkeit.' ),
			'security.alert' => array( 'phase' => 'Sicherheit', 'trigger' => 'Verdächtige Anmeldung, Rollenänderung oder API-Fehler', 'audience' => 'WebPortal-Admin, betroffener Nutzer', 'subject' => 'Sicherheitsmeldung', 'action' => 'Sicherheitsereignis prüfen', 'priority' => 'P1', 'body' => 'Kurz, beweisorientiert, ohne sensible Tokens oder vollständige Zahlungsdaten.' ),
		);
	}

	private static function email_guideline_html(): string {
		return '<h2>E-Mail-Leitbild</h2><p>E-Mails sind bei SwissToolRent ein professioneller Hinweis- und Sicherheitskanal. Vertragliche Kommunikation, Nachweise, Entscheidungen, Zahlungen, Kautionen und Supportverläufe bleiben im Portal. Jede E-Mail führt mit einer klaren Handlung zurück zum richtigen Portalvorgang.</p><ul><li>Sie-Form, Schweizer Rechtschreibung, kurze Sätze.</li><li>Keine erfundenen Preise, Termine, Trackingnummern, Zusagen oder rechtlichen Freigaben.</li><li>Keine Passwörter, Tokens, vollständigen Zahlungsdaten oder sensiblen Nachweise im Mailtext.</li><li>P1/P2-Meldungen müssen Entscheidung, Risiko und nächste Handlung sofort sichtbar machen.</li><li>Marketington vermeiden; ruhig, präzise, hochwertig, vertrauensbildend.</li></ul>';
	}

	private static function render_email_template( string $title, string $lead, string $body, string $action_label = '', string $action_url = '', string $preheader = '' ): string {
		$site_url = home_url( '/' );
		$contact = self::settings()['contact_email'] ?: get_option( 'admin_email' );
		$action = $action_label && $action_url ? '<p style="margin:26px 0 10px"><a href="' . esc_url( $action_url ) . '" style="display:inline-block;border-radius:10px;background:#0d6570;color:#ffffff;font-weight:800;line-height:1.2;padding:14px 20px;text-decoration:none">' . esc_html( $action_label ) . '</a></p>' : '';
		$content = wpautop( wp_kses_post( $body ) );
		return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . esc_html( $title ) . '</title></head><body style="margin:0;background:#eef4f2;color:#17353c;font-family:Arial,Helvetica,sans-serif"><span style="display:none!important;visibility:hidden;opacity:0;color:transparent;height:0;width:0;overflow:hidden">' . esc_html( $preheader ?: $lead ) . '</span><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#eef4f2"><tr><td align="center" style="padding:28px 14px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:640px;background:#ffffff;border:1px solid #d8e4e1;border-radius:18px;overflow:hidden;box-shadow:0 18px 50px rgba(18,55,61,.12)"><tr><td style="background:#082f39;padding:28px 30px 24px"><img src="' . esc_url( self::logo_url() ) . '" width="220" alt="SwissToolRent" style="display:block;max-width:220px;height:auto"><p style="margin:18px 0 0;color:#f1c85b;font-size:13px;font-weight:800;letter-spacing:.08em;text-transform:uppercase">Werkzeuge. Sicher geteilt.</p></td></tr><tr><td style="padding:34px 30px 18px"><h1 style="margin:0 0 14px;color:#0b3440;font-size:28px;line-height:1.15">' . esc_html( $title ) . '</h1><p style="margin:0;color:#486269;font-size:18px;line-height:1.55">' . esc_html( $lead ) . '</p><div style="margin-top:24px;color:#17353c;font-size:16px;line-height:1.62">' . $content . '</div>' . $action . '</td></tr><tr><td style="padding:22px 30px 30px"><div style="border-top:1px solid #dbe6e3;padding-top:18px;color:#5f7479;font-size:13px;line-height:1.55"><strong style="color:#17353c">Sicherheitshinweis</strong><br>SwissToolRent fragt nie per E-Mail nach Ihrem Passwort, vollständigen Zahlungsdaten oder Zugangscodes. Öffnen Sie sensible Vorgänge direkt über das Portal.<br><br><a href="' . esc_url( $site_url ) . '" style="color:#0d6570;font-weight:700;text-decoration:none">swisstoolrent.ch</a> · <a href="mailto:' . esc_attr( $contact ) . '" style="color:#0d6570;font-weight:700;text-decoration:none">' . esc_html( $contact ) . '</a></div></td></tr></table></td></tr></table></body></html>';
	}

	public static function brand_wp_mail( array $args ): array {
		$message = (string) ( $args['message'] ?? '' );
		if ( false !== strpos( $message, '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' ) ) {
			return $args;
		}
		$plain = trim( wp_strip_all_tags( str_replace( array( '<br>', '<br/>', '<br />' ), "\n", $message ) ) );
		$subject = (string) ( $args['subject'] ?? 'SwissToolRent' );
		$args['subject'] = self::normalise_subject( $subject );
		$args['message'] = self::render_email_template( self::clean_subject( $subject ), 'Eine Benachrichtigung aus dem SwissToolRent Portal.', esc_html( $plain ), 'Portal öffnen', home_url( '/portal/' ) );
		return $args;
	}

	public static function mail_content_type(): string {
		return 'text/html';
	}

	public static function mail_from_name(): string {
		return 'SwissToolRent';
	}

	public static function mail_from_address( string $from ): string {
		$domain = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		return $domain ? 'noreply@' . preg_replace( '/^www\./', '', (string) $domain ) : $from;
	}

	private static function clean_subject( string $subject ): string {
		return trim( preg_replace( '/^\[?swisstoolrent\.ch\]?\s*/i', '', $subject ) ) ?: 'SwissToolRent';
	}

	private static function normalise_subject( string $subject ): string {
		$clean = self::clean_subject( $subject );
		return '[SwissToolRent] ' . $clean;
	}

	public static function password_change_email( array $email, $user, array $userdata ): array {
		$name = is_object( $user ) ? ( $user->display_name ?: $user->user_email ) : ( $userdata['display_name'] ?? $userdata['user_email'] ?? 'Guten Tag' );
		$email['subject'] = self::normalise_subject( 'Passwort geändert' );
		$email['message'] = self::render_email_template( 'Passwort geändert', 'Diese Nachricht bestätigt eine Änderung an Ihrem SwissToolRent Zugang.', 'Hallo ' . esc_html( (string) $name ) . ",\n\nIhr Passwort wurde geändert. Falls Sie diese Änderung nicht selbst vorgenommen haben, öffnen Sie bitte sofort das Portal und kontaktieren Sie den Support.\n\nDiese Meldung dient Ihrer Sicherheit.", 'Konto prüfen', home_url( '/portal/' ), 'Sicherheitsbestätigung zu Ihrem SwissToolRent Zugang.' );
		return $email;
	}

	public static function email_change_email( array $email, array $user, array $userdata ): array {
		$email['subject'] = self::normalise_subject( 'E-Mail-Adresse geändert' );
		$email['message'] = self::render_email_template( 'E-Mail-Adresse geändert', 'Ihre Kontaktadresse im SwissToolRent Portal wurde angepasst.', "Die E-Mail-Adresse Ihres Kontos wurde geändert.\n\nFalls diese Änderung nicht von Ihnen stammt, melden Sie den Vorgang bitte umgehend über den Support Hub.", 'Konto prüfen', home_url( '/portal/' ) );
		return $email;
	}

	public static function retrieve_password_title( string $title, string $user_login, WP_User $user_data ): string {
		return self::normalise_subject( 'Passwort zurücksetzen' );
	}

	public static function retrieve_password_message( string $message, string $key, string $user_login, WP_User $user_data ): string {
		$url = network_site_url( 'wp-login.php?action=rp&key=' . rawurlencode( $key ) . '&login=' . rawurlencode( $user_login ), 'login' );
		return self::render_email_template( 'Passwort zurücksetzen', 'Sie haben einen Link zum Zurücksetzen Ihres Passworts angefordert.', 'Falls Sie diese Anfrage selbst ausgelöst haben, setzen Sie Ihr Passwort über den folgenden Button neu. Wenn Sie die Anfrage nicht kennen, können Sie diese Nachricht ignorieren; Ihr bisheriges Passwort bleibt gültig.', 'Passwort neu setzen', $url, 'Link zum sicheren Zurücksetzen Ihres Passworts.' );
	}

	public static function new_user_notification_email( array $email, WP_User $user, string $blogname ): array {
		$email['subject'] = self::normalise_subject( 'Ihr Zugang ist bereit' );
		$email['message'] = self::render_email_template( 'Ihr Zugang ist bereit', 'Ihr SwissToolRent Konto wurde erstellt.', 'Willkommen bei SwissToolRent. Öffnen Sie das Portal, um Ihre Rolle, Vorgänge und die nächsten Schritte zu sehen. Vertragsrelevante Kommunikation und Nachweise bleiben im Portal gespeichert.', 'Portal öffnen', home_url( '/portal/' ) );
		return $email;
	}

	public static function login_assets(): void {
		wp_enqueue_style( 'swisstoolrent-account', STR_CORE_URL . 'assets/account.css', array(), STR_CORE_VERSION );
		wp_enqueue_script( 'google-identity-services', 'https://accounts.google.com/gsi/client', array(), null, true );
		wp_enqueue_script( 'swisstoolrent-auth', STR_CORE_URL . 'assets/auth.js', array( 'google-identity-services' ), STR_CORE_VERSION, true );
		$css = 'body.login{background:#eef4f2;color:#17353c}.login h1 a{width:260px;height:84px;background-image:url("' . esc_url( self::logo_url() ) . '");background-size:contain;background-position:center;background-repeat:no-repeat}.login form{border:1px solid #d8e4e1;border-radius:18px;box-shadow:0 18px 50px rgba(18,55,61,.12)}.login .button-primary{background:#0d6570;border-color:#0d6570;font-weight:800}.login .button-primary:hover,.login .button-primary:focus{background:#094d57;border-color:#094d57}.login #nav a,.login #backtoblog a{color:#0d6570}.str-login-google{max-width:320px;margin:14px auto 0;padding:18px 22px;border:1px solid #d8e4e1;border-radius:16px;background:#fff;box-shadow:0 8px 24px rgba(18,55,61,.08)}.str-login-google p{margin:0 0 12px;color:#486269}.str-login-google .str-google-auth{margin-top:0;justify-content:center}.str-login-note{max-width:320px;margin:14px auto;color:#5f7479;text-align:center}.str-google-fallback{display:none!important}';
		wp_add_inline_style( 'swisstoolrent-account', $css );
		wp_localize_script( 'swisstoolrent-auth', 'STRPortal', array( 'restNonce' => wp_create_nonce( 'wp_rest' ) ) );
	}

	public static function login_header_url(): string {
		return home_url( '/' );
	}

	public static function login_header_text(): string {
		return 'SwissToolRent';
	}

	public static function login_message( string $message ): string {
		$s = self::settings();
		if ( empty( $s['google_client_id'] ) ) {
			return $message . '<p class="str-login-note">Google-Anmeldung wird nach Hinterlegung der Client-ID angezeigt.</p>';
		}
		return $message . '<div class="str-login-google"><p>Empfohlen: sicher mit Google anmelden.</p><div class="str-google-auth" data-client-id="' . esc_attr( $s['google_client_id'] ) . '" data-nonce-url="' . esc_url( rest_url( 'swisstoolrent/v1/google-nonce' ) ) . '" data-session-url="' . esc_url( rest_url( 'swisstoolrent/v1/google-session' ) ) . '" data-portal-url="' . esc_url( home_url( '/portal/' ) ) . '"></div><p class="str-auth-status" role="status"></p></div>';
	}

	public static function favicon_links(): void {
		$mark = esc_url( self::mark_url() );
		echo '<link rel="icon" href="' . $mark . '" type="image/svg+xml">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . $mark . '">' . "\n";
	}

	public static function ensure_pages(): void {
		$pages = array(
			'portal' => array( 'Portal', '[swisstoolrent_portal]' ),
			'tool-hub' => array( 'Tool Hub', '[swisstoolrent_toolhub]' ),
			'support-hub' => array( 'Support Hub', '[swisstoolrent_supporthub]' ),
			'prozess-studio' => array( 'Prozess Studio', '[swisstoolrent_process_studio]' ),
			'registrieren' => array( 'Mit Google registrieren', '[swisstoolrent_registration]' ),
			'datenschutz' => array( 'Datenschutzerklärung', self::privacy_page_content() ),
			'nutzungsbedingungen' => array( 'Nutzungsbedingungen', self::terms_page_content() ),
			'agb' => array( 'Allgemeine Geschäftsbedingungen', self::legal_page_content( 'agb' ) ),
			'cookie-richtlinie' => array( 'Cookie-Richtlinie', self::legal_page_content( 'cookies' ) ),
			'plattformrichtlinien' => array( 'Plattformrichtlinien', self::legal_page_content( 'platform' ) ),
			'sicherheit' => array( 'Sicherheit und Vertrauen', self::legal_page_content( 'security' ) ),
			'mietbedingungen' => array( 'Mietbedingungen', self::legal_page_content( 'rental' ) ),
			'hilfe' => array( 'Hilfe und häufige Fragen', self::legal_page_content( 'help' ) ),
			'kontakt' => array( 'Kontakt', self::legal_page_content( 'contact' ) ),
			'impressum' => array( 'Impressum', self::imprint_page_content() ),
		);
		foreach ( $pages as $slug => $page ) {
			if ( get_page_by_path( $slug ) ) {
				continue;
			}
			wp_insert_post(
				array(
					'post_title' => $page[0],
					'post_name' => $slug,
					'post_content' => $page[1],
					'post_status' => 'publish',
					'post_type' => 'page',
				)
			);
		}
	}

	private static function legal_page_content( string $type ): string {
		$lead = '<p><strong>Stand: 13. September 2026 · Pilotfassung</strong></p>';
		$documents = array(
			'agb' => '<h2>1. Zweck und Geltungsbereich</h2><p>Diese AGB regeln die Nutzung von SwissToolRent, des Tool Hub und der vorbereiteten Vermittlungsfunktionen. SwissToolRent stellt die technische Plattform bereit und ist nicht Eigentümerin der von Dritten angebotenen Werkzeuge.</p><h2>2. Konten und Rollen</h2><p>Kontoinhaber halten ihre Angaben aktuell. Firmenadministratoren sind für Mitarbeitende, Rollen und interne Freigaben verantwortlich. Missbrauch, Umgehung von Prüfungen und falsche Werkzeugangaben sind untersagt.</p><h2>3. Tool Hub und Tool Passport</h2><p>Automatisch erkannte Daten sind kontrollpflichtige Vorschläge. Herstellerdaten, Identität, Lieferumfang, Zustand, Preise, Kaution und Versand müssen vor einer Veröffentlichung plausibilisiert und freigegeben werden.</p><h2>4. Vermittlung und Verträge</h2><p>Ein Mietvertrag kommt zwischen Vermieter und Mieter zustande. Preise, Kaution, Übergabe, Rückgabe, Versand und Stornierung werden vor Abschluss ausgewiesen. Produktive Zahlungen und Vermittlungen bleiben bis zur dokumentierten Freigabe deaktiviert.</p><h2>5. Haftung und Support</h2><p>Schäden, Fehlteile und Abweichungen werden beweisgestützt im Support Hub behandelt. Automatische Belastungen erfolgen nicht bei strittigen Fällen. Zwingendes Schweizer Recht bleibt vorbehalten.</p>',
			'cookies' => '<h2>Notwendige Speicherungen</h2><p>SwissToolRent verwendet technisch notwendige Cookies für Anmeldung, Sitzungsschutz, Sprache, Sicherheit und Einwilligungsstatus. Ohne diese Funktionen kann das Portal nicht zuverlässig betrieben werden.</p><h2>Optionale Kategorien</h2><p>Analyse-, Komfort- oder Marketingdienste werden nur nach ausdrücklicher Auswahl aktiviert. Im aktuellen Pilotbetrieb sind keine Marketing-Cookies vorgesehen.</p><h2>Google und Stripe</h2><p>Beim Start der Google-Anmeldung oder eines Stripe-Testcheckouts können die jeweiligen Anbieter eigene technisch erforderliche Speicherungen setzen. Die Anbieter werden erst beim bewussten Aufruf eingebunden.</p><h2>Einstellungen ändern</h2><p>Ihre Auswahl kann jederzeit über die Cookie-Einstellungen im Fussbereich geändert werden. Notwendige Sicherheitscookies lassen sich nur durch Abmeldung oder Browsereinstellungen entfernen.</p>',
			'platform' => '<h2>Vermittlerrolle</h2><p>SwissToolRent stellt Suche, Tool Passport, Kommunikation und Nachweise bereit. Vermieter bleiben für Eigentum, rechtmässiges Angebot, Einsatzfähigkeit und vollständigen Lieferumfang verantwortlich.</p><h2>Einsatzbereitschaft</h2><p>Ein vermietetes Werkzeug muss sicher, funktionsfähig und für den beschriebenen Standardeinsatz vollständig sein. Erforderliches Standardzubehör ist im Lieferumfang auszuweisen; Verbrauchsmaterial ist klar als enthalten, optional oder vom Mieter bereitzustellen zu kennzeichnen.</p><h2>Identifikation und Medien</h2><p>Unklare Fotos oder widersprüchliche Typenschilder führen zu Nachforderungen. Eine KI-Schätzung darf keine eindeutige Identifikation ersetzen. Quellen, Korrekturen und Freigaben bleiben nachvollziehbar.</p><h2>Konflikte und Geldbewegungen</h2><p>Bei Widerspruch, Schaden oder Inventarabweichung wird der Vorgang in den Support Hub überführt. Strittige Kautions- oder Zahlungsbewegungen werden bis zur Prüfung pausiert.</p>',
			'security' => '<h2>Technische Sicherheit</h2><p>Öffentliche Seiten und Backend-Verbindungen verwenden HTTPS. Anmeldungen erfolgen über Google Identity; SwissToolRent erhält kein Google-Passwort. Sitzungen sind zeitlich begrenzt und rollenbasiert.</p><h2>Nachvollziehbarkeit</h2><p>Identifikation, Freigaben, Statuswechsel und Supportereignisse werden revisionsfähig protokolliert. Kritische Entscheidungen benötigen definierte Berechtigungen und gegebenenfalls das Vier-Augen-Prinzip.</p><h2>Fotos und QR-Codes</h2><p>Originalnachweise werden nicht durch Marketinggrafiken ersetzt. QR-Zuordnung, Lesbarkeit und Position werden vor der Freigabe geprüft. Sicherheitsrelevante Mängel blockieren die Vermietung.</p><h2>Vorfall melden</h2><p>Verdächtige Aktivitäten oder Sicherheitsprobleme melden Sie bitte unverzüglich über den Support Hub oder an <a href="mailto:info@swisstoolrent.ch">info@swisstoolrent.ch</a>.</p>',
			'rental' => '<h2>Pflichten des Vermieters</h2><p>Das Werkzeug muss bei Übergabe funktions- und einsatzfähig, sicher und entsprechend dem bestätigten Lieferumfang vollständig sein. Bekannte Einschränkungen müssen vor der Buchung offengelegt werden.</p><h2>Pflichten des Mieters</h2><p>Das Werkzeug ist bestimmungsgemäss, sorgfältig und nur durch befähigte Personen zu verwenden. Sicherheitsanweisungen, Rückgabezeitpunkt und vereinbarte Einsatzgrenzen sind einzuhalten.</p><h2>Übergabe und Rückgabe</h2><p>QR-Code, Fotos, Inventarliste, Zustand, Zählerstände und Zeitstempel bilden die gemeinsame Faktenbasis. Abweichungen werden vor Bestätigung sichtbar gemacht.</p><h2>Schaden, Verlust und Kaution</h2><p>Ein festgestellter Unterschied eröffnet einen Supportfall. Wiederbeschaffungswerte werden belegt und geprüft. Strittige Beträge werden nicht allein aufgrund einer automatischen Erkennung belastet.</p>',
			'help' => '<h2>Wie registriere ich mich?</h2><p>Wählen Sie „Mit Google fortfahren“. Nach erfolgreicher Bestätigung wird zunächst ein kostenloses Konto angelegt.</p><h2>Wo finde ich den Tool Hub?</h2><p>Nach der Anmeldung führt „Mein Portal“ zu den für Ihre Rolle freigegebenen Bereichen. Der Tool Hub verwaltet Werkzeuge, Tool Passports, Zubehör, Standorte und Freigaben.</p><h2>Wo melde ich ein Problem?</h2><p>Im Support Hub erfassen Sie Schäden, Fehlteile, Funktions- und Versandprobleme. Der gesamte Verlauf bleibt beim Vorgang gespeichert.</p><h2>Warum kann ein Werkzeug nicht veröffentlicht werden?</h2><p>Fehlende Identität, unvollständiger Lieferumfang, ungeklärte Einsatzbereitschaft, Versandblocker oder offene Freigaben verhindern eine Veröffentlichung.</p><h2>Wie erhalte ich Hilfe?</h2><p>Nutzen Sie den Support Hub oder schreiben Sie an <a href="mailto:info@swisstoolrent.ch">info@swisstoolrent.ch</a>.</p>',
			'contact' => '<h2>SwissToolRent erreichen</h2><p>E-Mail: <a href="mailto:info@swisstoolrent.ch">info@swisstoolrent.ch</a></p><p>Für bestehende Werkzeug-, Buchungs-, Versand- oder Schadenfälle verwenden Sie bitte den Support Hub. Dadurch bleiben Identität, Medien und Verlauf korrekt zugeordnet.</p><h2>Sicherheitsmeldungen</h2><p>Bitte kennzeichnen Sie sicherheitsrelevante Hinweise im Betreff eindeutig und übermitteln Sie keine Passwörter oder vollständigen Zahlungsdaten.</p>',
		);
		return $lead . ( $documents[ $type ] ?? '' ) . '<p><em>Diese Pilotfassung ersetzt keine abschliessende Prüfung durch eine für Schweizer Recht qualifizierte Fachperson.</em></p>';
	}

	private static function privacy_page_content(): string {
		return '<p><strong>Stand: 12. September 2026 · Pilotfassung</strong></p>' .
			'<h2>Verantwortliche Stelle</h2><p>SwissToolRent, Schweiz. Kontakt: <a href="mailto:info@swisstoolrent.ch">info@swisstoolrent.ch</a>.</p>' .
			'<h2>Google-Anmeldung</h2><p>Für die Registrierung und Anmeldung verwendet SwissToolRent Google Identity Services. Dabei werden die von Google bestätigte E-Mail-Adresse, der Anzeigename, eine eindeutige Google-Kennung und – sofern vorhanden – das Profilbild verarbeitet. Das Google-Passwort wird von SwissToolRent weder empfangen noch gespeichert.</p>' .
			'<p>Kalender oder andere Google-Dienste werden nicht automatisch freigeschaltet. Eine spätere Anbindung benötigt eine separate, transparente Einwilligung.</p>' .
			'<h2>Zwecke und Aufbewahrung</h2><p>Die Daten werden zur Kontoführung, Zugriffskontrolle, Missbrauchsprävention sowie zur Durchführung eigener Werkzeug- und Mietvorgänge verarbeitet. Nachweise und Vorgangsdaten werden nur so lange aufbewahrt, wie dies für Vertrag, Sicherheit, gesetzliche Pflichten oder die Bearbeitung offener Fälle erforderlich ist.</p>' .
			'<h2>Empfänger und Sicherheit</h2><p>Daten werden nur an notwendige technische Dienstleister übermittelt. Zahlungen werden über Stripe im jeweils ausgewiesenen Betriebsmodus verarbeitet. Zugänge werden rollenbasiert geschützt; sicherheitskritische Freigaben werden protokolliert.</p>' .
			'<h2>Ihre Rechte</h2><p>Sie können Auskunft, Berichtigung, Löschung oder Einschränkung verlangen und einer nicht zwingenden Verarbeitung widersprechen. Wenden Sie sich dafür an info@swisstoolrent.ch. Gesetzliche Aufbewahrungspflichten bleiben vorbehalten.</p>' .
			'<p>Diese Fassung wird vor dem produktiven Marktplatzstart rechtlich abschliessend geprüft und an die dann aktiven Anbieter und Datenflüsse angepasst.</p>';
	}

	private static function terms_page_content(): string {
		return '<p><strong>Stand: 12. September 2026 · Pilotfassung</strong></p>' .
			'<h2>Geltungsbereich</h2><p>Diese Nutzungsbedingungen gelten für Konten und den Pilotbetrieb des SwissToolRent Tool Hub. SwissToolRent stellt die technische Plattform und digitale Dokumentation bereit.</p>' .
			'<h2>Konto und Zugänge</h2><p>Nutzer sind für die Richtigkeit ihrer Angaben und die sichere Verwendung ihres Google-Kontos verantwortlich. Firmenadministratoren vergeben Rechte nur an berechtigte Mitarbeitende.</p>' .
			'<h2>Abonnemente</h2><p>Tarif, Preis, Laufzeit und Testphase werden vor Abschluss angezeigt. Im Testbetrieb von Stripe werden keine echten Zahlungsmittel belastet. Produktive Abonnemente werden erst nach gesonderter Freigabe angeboten.</p>' .
			'<h2>Werkzeugdaten</h2><p>Automatisch erkannte Daten sind Vorschläge und müssen vor einer Freigabe kontrolliert werden. Ein Abonnement veröffentlicht kein Werkzeug automatisch. Für eine externe Freigabe sind Identität, Lieferumfang, Einsatzbereitschaft und Vermietregeln separat zu bestätigen.</p>' .
			'<h2>Pilotvorbehalt</h2><p>Der Pilot dient der Erprobung. Produktive Zahlungen, Versicherungs- und Versandleistungen sowie verbindliche Mietabschlüsse werden erst nach den ausgewiesenen Freigaben aktiviert.</p>';
	}

	private static function imprint_page_content(): string {
		return '<p><strong>SwissToolRent · Pilotbetrieb</strong></p>' .
			'<p>Digitale Plattform mit Tool Hub und vorbereiteter Vermittlung von Werkzeugmieten in der Schweiz.</p>' .
			'<h2>Kontakt</h2><p>E-Mail: <a href="mailto:info@swisstoolrent.ch">info@swisstoolrent.ch</a><br>Website: <a href="https://swisstoolrent.ch/">swisstoolrent.ch</a></p>' .
			'<p>Die vollständigen Betreiber- und Adressangaben werden vor Aufnahme des produktiven Geschäftsbetriebs ergänzt und rechtlich geprüft.</p>';
	}

	public static function register_settings(): void {
		register_setting( 'str_core', self::OPTION, array( 'sanitize_callback' => array( self::class, 'sanitize_settings' ) ) );
	}

	public static function sanitize_settings( $input ): array {
		$current = self::settings();
		$input = is_array( $input ) ? $input : array();
		return array(
			'platform_name' => sanitize_text_field( $input['platform_name'] ?? $current['platform_name'] ),
			'operator_name' => sanitize_text_field( $input['operator_name'] ?? $current['operator_name'] ),
			'contact_email' => sanitize_email( $input['contact_email'] ?? $current['contact_email'] ),
			'api_base_url' => self::sanitize_https_url( $input['api_base_url'] ?? $current['api_base_url'], self::DEFAULT_API ),
			'api_client_id' => sanitize_text_field( $input['api_client_id'] ?? $current['api_client_id'] ),
			'google_client_id' => sanitize_text_field( $input['google_client_id'] ?? $current['google_client_id'] ),
			'update_manifest_url' => self::sanitize_https_url( $input['update_manifest_url'] ?? $current['update_manifest_url'], self::DEFAULT_UPDATE_MANIFEST ),
			'theme_update_manifest_url' => self::sanitize_https_url( $input['theme_update_manifest_url'] ?? $current['theme_update_manifest_url'], self::DEFAULT_THEME_UPDATE_MANIFEST ),
			'locales' => array_values( array_intersect( array_map( 'sanitize_text_field', (array) ( $input['locales'] ?? $current['locales'] ) ), array( 'de-CH', 'fr-CH', 'it-CH', 'en' ) ) ),
			'gates' => $current['gates'],
			'configured' => ! empty( $input['platform_name'] ) && ! empty( $input['api_base_url'] ),
			'subscription_plans' => self::sanitize_plans( $input['subscription_plans'] ?? $current['subscription_plans'], $current['subscription_plans'] ),
		);
	}

	private static function sanitize_plans( $plans, array $fallback ): array {
		$result = array();
		foreach ( array( 'internal', 'external' ) as $code ) {
			$plan = is_array( $plans[ $code ] ?? null ) ? $plans[ $code ] : $fallback[ $code ];
			$status = strtoupper( sanitize_key( $plan['status'] ?? 'IN_REVIEW' ) );
			$result[ $code ] = array(
				'name' => sanitize_text_field( $plan['name'] ?? $fallback[ $code ]['name'] ),
				'monthly' => max( 0, (int) ( $plan['monthly'] ?? 0 ) ), 'yearly' => max( 0, (int) ( $plan['yearly'] ?? 0 ) ),
				'trial_days' => min( 90, max( 0, (int) ( $plan['trial_days'] ?? 14 ) ) ),
				'max_tools' => max( 1, (int) ( $plan['max_tools'] ?? 1 ) ), 'max_members' => max( 1, (int) ( $plan['max_members'] ?? 1 ) ),
				'status' => in_array( $status, array( 'DRAFT', 'IN_REVIEW', 'PUBLISHED', 'PAUSED' ), true ) ? $status : 'IN_REVIEW',
			);
		}
		return $result;
	}

	private static function sanitize_https_url( string $url, string $fallback ): string {
		$url = esc_url_raw( trim( $url ) );
		if ( ! $url || 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) ) {
			return $fallback;
		}
		return untrailingslashit( $url );
	}

	public static function admin_menu(): void {
		add_menu_page( 'SwissToolRent', 'SwissToolRent', 'str_manage_platform', 'swisstoolrent', array( self::class, 'render_setup' ), 'dashicons-admin-tools', 3 );
		add_submenu_page( 'swisstoolrent', 'Einrichtung', 'Einrichtung', 'str_manage_platform', 'swisstoolrent', array( self::class, 'render_setup' ) );
		add_submenu_page( 'swisstoolrent', 'Prüfungen und Freigaben', 'Prüfungen & Freigaben', 'str_manage_platform', 'swisstoolrent-gates', array( self::class, 'render_gates' ) );
		add_submenu_page( 'swisstoolrent', 'Abonnemente und Zugänge', 'Abos & Zugänge', 'str_manage_platform', 'swisstoolrent-subscriptions', array( self::class, 'render_subscriptions' ) );
		add_submenu_page( 'swisstoolrent', 'Benutzerverwaltung', 'Benutzer', 'str_manage_platform', 'swisstoolrent-users', array( self::class, 'render_users' ) );
		add_submenu_page( 'swisstoolrent', 'E-Mail-Leitbild und Prozesse', 'E-Mails & Prozesse', 'str_manage_platform', 'swisstoolrent-emails', array( self::class, 'render_email_processes' ) );
		add_submenu_page( 'swisstoolrent', 'Systemstatus', 'Systemstatus', 'str_manage_platform', 'swisstoolrent-status', array( self::class, 'render_status' ) );
	}

	public static function enqueue_assets(): void {
		wp_enqueue_style( 'swisstoolrent-core', STR_CORE_URL . 'assets/core.css', array(), STR_CORE_VERSION );
		wp_enqueue_style( 'swisstoolrent-account', STR_CORE_URL . 'assets/account.css', array( 'swisstoolrent-core' ), STR_CORE_VERSION );
		wp_enqueue_script( 'google-identity-services', 'https://accounts.google.com/gsi/client', array(), null, true );
		wp_enqueue_script( 'swisstoolrent-auth', STR_CORE_URL . 'assets/auth.js', array( 'google-identity-services' ), STR_CORE_VERSION, true );
		wp_enqueue_script( 'swisstoolrent-support-hub', STR_CORE_URL . 'assets/support-hub.js', array(), STR_CORE_VERSION, true );
		wp_localize_script( 'swisstoolrent-auth', 'STRPortal', array( 'restNonce' => wp_create_nonce( 'wp_rest' ) ) );
	}

	public static function enqueue_admin_assets( string $hook ): void {
		if ( false === strpos( $hook, 'swisstoolrent' ) ) {
			return;
		}
		wp_enqueue_style( 'swisstoolrent-core-admin', STR_CORE_URL . 'assets/core.css', array(), STR_CORE_VERSION );
		if ( false !== strpos( $hook, 'swisstoolrent-users' ) ) {
			wp_enqueue_script( 'swisstoolrent-user-admin', STR_CORE_URL . 'assets/user-admin.js', array(), STR_CORE_VERSION, true );
			wp_localize_script( 'swisstoolrent-user-admin', 'STRUserAdmin', array( 'endpoint' => rest_url( 'swisstoolrent/v1/admin-users' ), 'nonce' => wp_create_nonce( 'wp_rest' ) ) );
		}
	}

	public static function register_shortcodes(): void {
		add_shortcode( 'swisstoolrent_portal', array( self::class, 'portal_shortcode' ) );
		add_shortcode( 'swisstoolrent_toolhub', array( self::class, 'toolhub_shortcode' ) );
		add_shortcode( 'swisstoolrent_supporthub', array( self::class, 'supporthub_shortcode' ) );
		add_shortcode( 'swisstoolrent_process_studio', array( self::class, 'process_shortcode' ) );
		add_shortcode( 'swisstoolrent_status', array( self::class, 'status_shortcode' ) );
		add_shortcode( 'swisstoolrent_registration', array( self::class, 'registration_shortcode' ) );
	}

	public static function registration_shortcode(): string {
		$s = self::settings();
		if ( empty( $s['google_client_id'] ) ) return '<section class="str-portal-card str-wide"><small>GOOGLE-ANMELDUNG</small><h2>Registrierung vorbereitet</h2><p>Die Google Client-ID und die freigegebene Domain müssen zuerst durch einen WebPortal-Admin hinterlegt werden.</p></section>';
		return '<section class="str-portal-card str-wide str-registration"><style>.str-google-fallback{display:none!important}</style><small>KOSTENLOS STARTEN</small><h2>Mit Google registrieren</h2><p>Nach der Anmeldung wird Ihr kostenloses SwissToolRent-Konto sofort angelegt. Sie können suchen, Anfragen verwalten und später im Portal auf ein Tool-Hub-Abo wechseln.</p><div class="str-google-auth" data-client-id="' . esc_attr( $s['google_client_id'] ) . '" data-nonce-url="' . esc_url( rest_url( 'swisstoolrent/v1/google-nonce' ) ) . '" data-session-url="' . esc_url( rest_url( 'swisstoolrent/v1/google-session' ) ) . '" data-portal-url="' . esc_url( home_url( '/portal/' ) ) . '"></div><p class="str-auth-status" role="status"></p><p class="str-auth-note">Google übermittelt kein Passwort. Kalenderzugriff wird nicht automatisch erteilt. Während des Piloten sind nur freigeschaltete Google-Testkonten zugelassen.</p></section>';
	}

	public static function portal_shortcode(): string {
		if ( ! is_user_logged_in() && empty( $_COOKIE['str_portal_token'] ) ) {
			return '<section class="str-portal-card"><h2>Portalzugang</h2><p>Bitte melden Sie sich an, um Ihre SwissToolRent-Bereiche zu öffnen.</p>' . wp_login_form( array( 'echo' => false ) ) . '</section>';
		}
		$area = sanitize_key( (string) ( $_GET['bereich'] ?? '' ) );
		$view = sanitize_key( (string) ( $_GET['view'] ?? '' ) );
		$embedded_views = array(
			'buchungen' => array( 'bookings', 'Buchungen und Anfragen' ),
			'kommunikation' => array( 'communications', 'Kommunikations-Hub' ),
			'firma' => array( 'settings', 'Firmen-Einstellungen' ),
			'bookings' => array( 'bookings', 'Buchungen und Anfragen' ),
			'communications' => array( 'communications', 'Kommunikations-Hub' ),
			'settings' => array( 'settings', 'Firmen-Einstellungen' ),
		);
		$requested_view = $embedded_views[ $area ] ?? $embedded_views[ $view ] ?? null;
		if ( $requested_view ) {
			if ( 'settings' === $requested_view[0] && ! current_user_can( 'str_manage_company' ) ) {
				return '<section class="str-portal-card"><h2>Firmen-Einstellungen</h2><p>Dieser Bereich ist nur für Firmenadministratoren und WebPortal-Administratoren freigegeben.</p></section>';
			}
			return self::operational_embed( $requested_view[0], $requested_view[1] );
		}
		$role = current_user_can( 'str_manage_platform' ) ? 'WebPortal-Admin' : ( current_user_can( 'str_manage_company' ) ? 'B2B-Firmenadmin' : 'Registrierter Kunde' );
		$links = array(
			array( 'Tool Hub', home_url( '/tool-hub/' ), 'Werkzeuge, Passport, Vermietung, Kaution und Versand verwalten.' ),
			array( 'Support Hub', home_url( '/support-hub/' ), 'Schäden, Abweichungen, Versand- und Funktionsprobleme klären.' ),
			array( 'Buchungen', home_url( '/portal/?bereich=buchungen' ), 'Anfragen, Übergaben und Rückgaben bearbeiten.' ),
			array( 'Kommunikation', home_url( '/portal/?bereich=kommunikation' ), 'Vorgangsbezogene Nachrichten und Aufgaben.' ),
		);
		if ( current_user_can( 'str_manage_company' ) ) {
			$links[] = array( 'Firmen-Einstellungen', home_url( '/portal/?bereich=firma' ), 'Firma, Orte, Fahrzeuge, Mitarbeitende und Finanzvorgaben.' );
		}
		if ( current_user_can( 'str_manage_platform' ) ) {
			$links[] = array( 'Prozess Studio', home_url( '/prozess-studio/' ), 'Globale Prozesse entwerfen, simulieren und freigeben.' );
			$links[] = array( 'WebPortal-Verwaltung', admin_url( 'admin.php?page=swisstoolrent' ), 'Backend, Rollen, Systemstatus und Freigaben.' );
		}
		$has_portal_session = ! empty( $_COOKIE['str_portal_token'] );
		$html = '<section class="str-role-context"><small>AKTIVE ANSICHT</small><h2>' . esc_html( $role ) . '</h2><p>Alle fachlichen Berechtigungen werden zusätzlich durch das SwissToolRent-Backend geprüft.</p></section>';
		if ( $has_portal_session ) {
			$html .= '<section class="str-portal-card str-wide str-subscription-card"><small>AKTUELLES ABO</small><h2>Kostenlos</h2><p>Ihr kostenloses Konto ist aktiv. Ein Tool-Hub-Abo können Sie hier sicher im Stripe-Testmodus ausprobieren; es wird kein echtes Zahlungsmittel belastet.</p><div class="str-plan-actions"><button class="str-button str-checkout-button" data-plan="MANAGEMENT_INTERNAL" data-interval="month">Intern · CHF 29/Monat testen</button><button class="str-button str-checkout-button" data-plan="MANAGEMENT_MARKETPLACE" data-interval="month">Intern &amp; Extern · CHF 49/Monat testen</button></div><p class="str-checkout-status" role="status"></p></section>';
		}
		$html .= '<div class="str-portal-grid">';
		foreach ( $links as $link ) {
			$html .= '<a class="str-portal-card" href="' . esc_url( $link[1] ) . '"><h3>' . esc_html( $link[0] ) . '</h3><p>' . esc_html( $link[2] ) . '</p><strong>Öffnen →</strong></a>';
		}
		return $html . '</div>';
	}

	public static function toolhub_shortcode(): string {
		if ( ! current_user_can( 'str_access_portal' ) ) {
			return '<section class="str-portal-card"><h2>Tool Hub</h2><p>Bitte melden Sie sich mit Google an, um Werkzeuge und Tool Passports zu verwalten.</p><a class="str-button" href="' . esc_url( home_url( '/registrieren/' ) ) . '">Mit Google anmelden</a></section>';
		}
		return self::operational_embed( 'hub', 'Tool Hub' );
	}

	public static function supporthub_shortcode(): string {
		if ( ! current_user_can( 'str_access_portal' ) ) return '<p>Dieser Bereich ist für Ihre Rolle nicht freigegeben.</p>';
		ob_start(); ?>
		<div class="str-support-hub" data-support-url="<?php echo esc_url( rest_url( 'swisstoolrent/v1/support-cases' ) ); ?>">
			<section class="str-support-hero">
				<div><small>SUPPORT HUB</small><h2>Was können wir für Sie klären?</h2><p>Vom schnellen Bedienhinweis bis zum dokumentierten Schadenfall: Jeder Vorgang landet geordnet bei der richtigen Stelle und bleibt nachvollziehbar.</p></div>
				<div class="str-support-orbit" aria-hidden="true"><span>?</span><i></i><b>✓</b></div>
			</section>
			<nav class="str-support-nav" aria-label="Support Hub Bereiche">
				<button type="button" class="is-active" data-support-panel="overview">Übersicht</button>
				<button type="button" data-support-panel="contact">Support kontaktieren</button>
				<button type="button" data-support-panel="damage">Schaden melden &amp; QR scannen</button>
				<button type="button" data-support-panel="manual">Portal-Handbuch</button>
				<button type="button" data-support-panel="cases">Meine Fälle</button>
			</nav>

			<section class="str-support-panel is-active" data-panel="overview">
				<div class="str-support-choice-grid">
					<button type="button" data-open-support="contact"><span>✦</span><strong>Support kontaktieren</strong><small>Frage strukturiert einreichen</small></button>
					<button type="button" data-open-support="damage"><span>⌁</span><strong>Schaden oder Problem melden</strong><small>Werkzeug per QR eindeutig zuordnen</small></button>
					<button type="button" data-open-support="manual"><span>▤</span><strong>Portal-Handbuch</strong><small>Funktion interaktiv erklären lassen</small></button>
					<button type="button" data-open-support="cases"><span>◎</span><strong>Meine Supportfälle</strong><small>Status und Verlauf ansehen</small></button>
				</div>
			</section>

			<section class="str-support-panel" data-panel="contact">
				<div class="str-panel-heading"><small>GEFÜHRTER KONTAKT</small><h2>Support kontaktieren</h2><p>Die Auswahl sorgt dafür, dass Ihr Anliegen ohne Umwege beim richtigen Prozess landet.</p></div>
				<form class="str-support-form">
					<label>Bereich<select name="area" required><option value="">Bitte auswählen</option><option>Tool Hub &amp; Tool Passport</option><option>Werkzeug-Onboarding</option><option>Vermietung &amp; Buchung</option><option>Versand &amp; Rückgabe</option><option>Zahlung &amp; Kaution</option><option>Konto, Rollen &amp; Mitarbeitende</option><option>Prozess Studio</option><option>Datenschutz &amp; Sicherheit</option></select></label>
					<label>Art des Anliegens<select name="category"><option value="FUNCTION">Funktion oder Bedienung</option><option value="INVENTORY_DIFFERENCE">Lieferumfang oder Inventar</option><option value="DAMAGE">Schaden</option><option value="SHIPPING">Versand</option><option value="PAYMENT">Zahlung &amp; Kaution</option><option value="OTHER">Sonstiges</option></select></label>
					<label>Dringlichkeit<select name="priority"><option value="LOW">Kein Zeitdruck</option><option value="NORMAL" selected>Normal</option><option value="HIGH">Dringend – Vorgang blockiert</option><option value="CRITICAL">Kritisch – Sicherheit betroffen</option></select></label>
					<label>Bezug<select name="referenceType"><option value="GENERAL">Allgemeine Frage</option><option value="TOOL">Werkzeug / Tool Passport</option><option value="BOOKING">Buchung / Mietvorgang</option><option value="ORGANIZATION">Firma / Organisation</option></select></label>
					<label class="str-wide">Titel<input name="title" required minlength="3" maxlength="180" placeholder="Kurz und eindeutig, z. B. Rückgabe kann nicht abgeschlossen werden"></label>
					<label class="str-wide">Was ist passiert und was möchten Sie erreichen?<textarea name="description" required minlength="5" maxlength="10000" rows="6" placeholder="Beschreiben Sie Ausgangslage, bereits versuchte Schritte und gewünschtes Ergebnis."></textarea></label>
					<label class="str-wide str-consent"><input type="checkbox" required> Ich bestätige, dass die Angaben korrekt sind und keine Passwörter oder vollständigen Zahlungsdaten enthalten.</label>
					<button class="str-button str-accent-button" type="submit">Supportfall verbindlich anlegen</button><p class="str-support-status" role="status"></p>
				</form>
			</section>

			<section class="str-support-panel" data-panel="damage">
				<div class="str-panel-heading"><small>SCHADEN &amp; ABWEICHUNG</small><h2>Werkzeug zuerst eindeutig zuordnen</h2><p>Scannen Sie den SwissToolRent-QR-Code am Werkzeug. Auf Mobilgeräten startet bevorzugt die Rückkamera.</p></div>
				<div class="str-qr-workflow">
					<div class="str-qr-camera"><video playsinline muted></video><div class="str-scan-frame" aria-hidden="true"></div><p class="str-qr-status" role="status">Kamera noch nicht gestartet.</p></div>
					<div class="str-qr-actions"><button type="button" class="str-button str-start-qr">Rückkamera starten</button><label class="str-upload-button">QR-Bild auswählen<input type="file" accept="image/*" capture="environment"></label><label>QR-/Tool-ID manuell eingeben<input class="str-tool-reference" placeholder="z. B. STR:B-1042"></label><button type="button" class="str-button str-confirm-tool">Werkzeug übernehmen</button><p><strong>Erkanntes Werkzeug:</strong> <span class="str-detected-tool">Noch keines zugeordnet</span></p></div>
				</div>
				<button type="button" class="str-damage-continue" data-open-support="contact">Mit diesem Werkzeug Schadenfall erfassen →</button>
			</section>

			<section class="str-support-panel" data-panel="manual">
				<div class="str-panel-heading"><small>INTERAKTIVES PORTAL-HANDBUCH</small><h2>Wo möchten Sie weiterkommen?</h2><p>Suchen Sie nach einer Funktion oder wählen Sie einen Themenbereich. Die Erklärung führt Sie direkt zum passenden Ort.</p></div>
				<label class="str-manual-search"><span>Handbuch durchsuchen</span><input type="search" placeholder="z. B. Kaution, Mitarbeiter, Werkzeug löschen …"></label>
				<div class="str-manual-layout">
					<nav class="str-manual-topics" aria-label="Handbuchthemen">
						<button type="button" class="is-active" data-manual-topic="start">Erste Schritte</button><button type="button" data-manual-topic="tool">Werkzeug anlegen</button><button type="button" data-manual-topic="rental">Vermieten &amp; Versand</button><button type="button" data-manual-topic="company">Firma &amp; Rollen</button><button type="button" data-manual-topic="support">Support &amp; Schäden</button><button type="button" data-manual-topic="process">Prozess Studio</button>
					</nav>
					<div class="str-manual-content" aria-live="polite"></div>
				</div>
			</section>

			<section class="str-support-panel" data-panel="cases">
				<div class="str-panel-heading"><small>MEINE FÄLLE</small><h2>Status und Verlauf</h2><p>Offene, wartende und gelöste Fälle bleiben hier mit ihrer eindeutigen Fallnummer sichtbar.</p></div>
				<div class="str-support-list" aria-live="polite"><p>Supportfälle werden geladen …</p></div>
			</section>
		</div>
		<?php return (string) ob_get_clean();
	}

	public static function process_shortcode(): string {
		if ( ! current_user_can( 'str_manage_platform' ) ) {
			return '<p>Das Prozess Studio ist nur für berechtigte WebPortal-Administratoren sichtbar.</p>';
		}
		return self::operational_embed( 'processes', 'Prozess Studio' );
	}

	private static function operational_embed( string $view, string $title ): string {
		$token = isset( $_COOKIE['str_portal_token'] ) ? (string) $_COOKIE['str_portal_token'] : '';
		$ticket = '';
		if ( '' !== $token ) {
			$result = self::api_json_request( '/identity/embed-ticket', 'POST', array(), $token );
			$ticket = sanitize_text_field( (string) ( $result['ticket'] ?? '' ) );
		}
		$url = 'https://swisstoolrent.javis.ch/de-CH?view=' . rawurlencode( $view ) . '&embed=1';
		if ( '' !== $ticket ) $url .= '&embedTicket=' . rawurlencode( $ticket );
		return '<section class="str-operational-shell"><div class="str-operational-head"><div><small>LIVE-BACKEND</small><h2>' . esc_html( $title ) . '</h2><p>Die vollständige Portaloberfläche läuft direkt auf dem SwissToolRent-Backend.</p></div><a class="str-button" target="_blank" rel="noopener" href="' . esc_url( $url ) . '">In eigenem Fenster öffnen</a></div><iframe class="str-operational-frame" title="' . esc_attr( $title ) . '" src="' . esc_url( $url ) . '" allow="camera; geolocation; clipboard-write" loading="eager"></iframe></section>';
	}

	public static function status_shortcode(): string {
		$result = self::api_request( '/health' );
		return '<span class="str-api-status ' . ( $result['ok'] ? 'is-ok' : 'is-error' ) . '">' . esc_html( $result['message'] ) . '</span>';
	}

	public static function save_settings(): void {
		self::assert_platform_admin( 'str_save_settings' );
		$settings = self::sanitize_settings( wp_unslash( $_POST['str'] ?? array() ) );
		update_option( self::OPTION, $settings, false );
		$secret = isset( $_POST['api_secret'] ) ? trim( (string) wp_unslash( $_POST['api_secret'] ) ) : '';
		if ( '' !== $secret ) {
			update_option( self::SECRET_OPTION, self::encrypt( $secret ), false );
		}
		self::redirect_admin( 'saved' );
	}

	public static function test_connection(): void {
		self::assert_platform_admin( 'str_test_connection' );
		$result = self::api_request( '/health' );
		self::redirect_admin( $result['ok'] ? 'connected' : 'failed' );
	}

	public static function save_gate(): void {
		self::assert_platform_admin( 'str_save_gate' );
		$settings = self::settings();
		$key = sanitize_key( $_POST['gate'] ?? '' );
		$status = sanitize_key( $_POST['status'] ?? '' );
		$status = strtoupper( $status );
		if ( array_key_exists( $key, $settings['gates'] ) && in_array( $status, array( 'OPEN', 'IN_REVIEW', 'APPROVED' ), true ) ) {
			$settings['gates'][ $key ] = $status;
			update_option( self::OPTION, $settings, false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=swisstoolrent-gates&str_notice=gate-saved' ) );
		exit;
	}

	private static function assert_platform_admin( string $nonce_action ): void {
		if ( ! current_user_can( 'str_manage_platform' ) ) {
			wp_die( esc_html__( 'Keine Berechtigung.', 'swisstoolrent-core' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce_action );
	}

	private static function redirect_admin( string $notice ): void {
		wp_safe_redirect( admin_url( 'admin.php?page=swisstoolrent&str_notice=' . rawurlencode( $notice ) ) );
		exit;
	}

	private static function encrypt( string $plain ): string {
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return '';
		}
		$key = hash( 'sha256', wp_salt( 'auth' ), true );
		$iv = random_bytes( 12 );
		$tag = '';
		$cipher = openssl_encrypt( $plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
		return $cipher ? base64_encode( $iv . $tag . $cipher ) : '';
	}

	private static function decrypt_secret(): string {
		$stored = (string) get_option( self::SECRET_OPTION, '' );
		$raw = base64_decode( $stored, true );
		if ( ! $raw || strlen( $raw ) < 29 || ! function_exists( 'openssl_decrypt' ) ) {
			return '';
		}
		$iv = substr( $raw, 0, 12 );
		$tag = substr( $raw, 12, 16 );
		$cipher = substr( $raw, 28 );
		$result = openssl_decrypt( $cipher, 'aes-256-gcm', hash( 'sha256', wp_salt( 'auth' ), true ), OPENSSL_RAW_DATA, $iv, $tag );
		return is_string( $result ) ? $result : '';
	}

	private static function api_request( string $path ): array {
		$settings = self::settings();
		$headers = array( 'Accept' => 'application/json' );
		if ( $settings['api_client_id'] ) {
			$headers['X-STR-Client'] = $settings['api_client_id'];
		}
		$secret = self::decrypt_secret();
		if ( $secret ) {
			$headers['Authorization'] = 'Bearer ' . $secret;
		}
		$response = wp_remote_get( $settings['api_base_url'] . '/' . ltrim( $path, '/' ), array( 'timeout' => 8, 'redirection' => 0, 'sslverify' => true, 'headers' => $headers ) );
		if ( is_wp_error( $response ) ) {
			return array( 'ok' => false, 'message' => 'Backend nicht erreichbar' );
		}
		$code = wp_remote_retrieve_response_code( $response );
		return array( 'ok' => 200 === $code, 'message' => 200 === $code ? 'Backend verbunden' : 'Backend antwortet mit HTTP ' . $code );
	}

	private static function complete_google_session( array $result ) {
		if ( empty( $result['token'] ) || empty( $result['profile']['email'] ) ) return new WP_Error( 'str_google_login_failed', 'Google-Anmeldung fehlgeschlagen.', array( 'status' => 401 ) );
		$email = sanitize_email( (string) $result['profile']['email'] );
		if ( ! $email ) return new WP_Error( 'str_google_email_missing', 'Google hat keine bestätigte E-Mail-Adresse übermittelt.', array( 'status' => 401 ) );
		$user = get_user_by( 'email', $email );
		if ( ! $user ) {
			$base = sanitize_user( strtok( $email, '@' ), true );
			$base = $base ?: 'kunde';
			$login = $base;
			for ( $suffix = 2; username_exists( $login ); $suffix++ ) $login = $base . $suffix;
			$user_id = wp_insert_user( array(
				'user_login' => $login,
				'user_email' => $email,
				'user_pass' => wp_generate_password( 32, true, true ),
				'display_name' => sanitize_text_field( (string) ( $result['profile']['displayName'] ?? $login ) ),
				'role' => 'swisstoolrent_customer',
			) );
			if ( is_wp_error( $user_id ) ) return new WP_Error( 'str_user_creation_failed', 'Das Kundenkonto konnte nicht angelegt werden.', array( 'status' => 500 ) );
			$user = get_user_by( 'id', $user_id );
		}
		if ( ! $user ) return new WP_Error( 'str_user_resolution_failed', 'Das Kundenkonto konnte nicht geladen werden.', array( 'status' => 500 ) );
		$platform_roles = isset( $result['actor']['platformRoles'] ) && is_array( $result['actor']['platformRoles'] ) ? $result['actor']['platformRoles'] : array();
		if ( in_array( 'ADMIN', $platform_roles, true ) || in_array( 'SUPERADMIN', $platform_roles, true ) ) {
			$user->set_role( 'administrator' );
		} elseif ( isset( $result['actor']['organizationRole'] ) && 'ORG_ADMIN' === $result['actor']['organizationRole'] ) {
			$user->set_role( 'swisstoolrent_company_admin' );
		}
		update_user_meta( $user->ID, 'str_registration_provider', 'GOOGLE' );
		update_user_meta( $user->ID, 'str_google_subject', sanitize_text_field( (string) ( $result['profile']['providerSubject'] ?? '' ) ) );
		update_user_meta( $user->ID, 'str_account_tier', 'FREE' );
		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, true, is_ssl() );
		do_action( 'wp_login', $user->user_login, $user );
		setcookie( 'str_portal_token', $result['token'], array( 'expires' => time() + 1800, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Lax' ) );
		setcookie( 'str_google_nonce_ticket', '', array( 'expires' => time() - 3600, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Lax' ) );
		$response = new WP_REST_Response( null, 303 );
		$response->header( 'Location', home_url( '/portal/' ) );
		return $response;
	}

	private static function google_failure_redirect( string $reason = 'fehlgeschlagen' ): WP_REST_Response {
		$response = new WP_REST_Response( null, 303 );
		$response->header( 'Location', add_query_arg( 'google', sanitize_key( $reason ), home_url( '/registrieren/' ) ) );
		return $response;
	}

	public static function register_rest_routes(): void {
		register_rest_route( 'swisstoolrent/v1', '/health', array( 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => static function () { return rest_ensure_response( self::api_request( '/health' ) ); } ) );
		register_rest_route( 'swisstoolrent/v1', '/session-context', array( 'methods' => 'GET', 'permission_callback' => static function () { return is_user_logged_in(); }, 'callback' => static function () { return rest_ensure_response( array( 'role' => current_user_can( 'str_manage_platform' ) ? 'WEBPORTAL_ADMIN' : ( current_user_can( 'str_manage_company' ) ? 'BUSINESS_ADMIN' : 'CUSTOMER' ), 'capabilities' => array( 'portal' => current_user_can( 'str_access_portal' ), 'companyAdmin' => current_user_can( 'str_manage_company' ), 'platformAdmin' => current_user_can( 'str_manage_platform' ) ) ) ); } ) );
		register_rest_route( 'swisstoolrent/v1', '/admin-users(?:/(?P<user_id>[0-9a-f-]{36}))?', array( 'methods' => array( 'GET', 'PATCH', 'DELETE' ), 'permission_callback' => static function () { return current_user_can( 'str_manage_platform' ); }, 'callback' => static function ( WP_REST_Request $request ) {
			$token = self::decrypt_secret();
			if ( '' === $token && isset( $_COOKIE['str_portal_token'] ) ) $token = (string) $_COOKIE['str_portal_token'];
			if ( '' === $token ) return new WP_Error( 'str_service_session_missing', 'Der verschlüsselte Backend-Servicezugang fehlt in der SwissToolRent-Einrichtung.', array( 'status' => 401 ) );
			$user_id = sanitize_text_field( (string) $request->get_param( 'user_id' ) );
			$path = '/platform/users' . ( $user_id ? '/' . rawurlencode( $user_id ) : '' );
			if ( 'GET' === $request->get_method() && ! $user_id ) {
				$query = array_filter( array_map( 'sanitize_text_field', array( 'q' => (string) $request->get_param( 'q' ), 'state' => (string) $request->get_param( 'state' ), 'plan' => (string) $request->get_param( 'plan' ), 'page' => (string) $request->get_param( 'page' ) ) ) );
				if ( $query ) $path .= '?' . http_build_query( $query );
			}
			$body = in_array( $request->get_method(), array( 'PATCH', 'DELETE' ), true ) ? (array) $request->get_json_params() : array();
			return rest_ensure_response( self::api_json_request( $path, $request->get_method(), $body, $token ) );
		} ) );
		register_rest_route( 'swisstoolrent/v1', '/google-nonce', array( 'methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => static function () {
			$result = self::api_json_request( '/identity/google/nonce' );
			if ( ! empty( $result['nonceTicket'] ) ) setcookie( 'str_google_nonce_ticket', (string) $result['nonceTicket'], array( 'expires' => time() + 300, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'None' ) );
			return rest_ensure_response( $result );
		} ) );
		register_rest_route( 'swisstoolrent/v1', '/google-session', array( 'methods' => array( 'GET', 'POST' ), 'permission_callback' => '__return_true', 'callback' => static function ( WP_REST_Request $request ) {
			if ( 'GET' === $request->get_method() ) {
				if ( $request->get_param( 'error' ) ) return self::google_failure_redirect( 'abgebrochen' );
				$code = (string) $request->get_param( 'code' );
				$state = (string) $request->get_param( 'state' );
				if ( '' === $code || '' === $state ) return self::google_failure_redirect();
				$result = self::api_json_request( '/identity/google/code', 'POST', array(
					'code' => $code,
					'nonceTicket' => $state,
					'redirectUri' => rest_url( 'swisstoolrent/v1/google-session' ),
				) );
				if ( empty( $result['token'] ) ) return self::google_failure_redirect();
				return self::complete_google_session( $result );
			}
			$nonce_ticket = (string) $request->get_param( 'nonceTicket' );
			if ( '' === $nonce_ticket && isset( $_COOKIE['str_google_nonce_ticket'] ) ) $nonce_ticket = (string) $_COOKIE['str_google_nonce_ticket'];
			$result = self::api_json_request( '/identity/google', 'POST', array( 'credential' => (string) $request->get_param( 'credential' ), 'nonceTicket' => $nonce_ticket ) );
			$completed = self::complete_google_session( $result );
			if ( is_wp_error( $completed ) ) return $completed;
			return rest_ensure_response( array( 'authenticated' => true, 'redirectUrl' => home_url( '/portal/' ) ) );
		} ) );
		register_rest_route( 'swisstoolrent/v1', '/checkout-session', array( 'methods' => 'POST', 'permission_callback' => static function () { return is_user_logged_in(); }, 'callback' => static function ( WP_REST_Request $request ) {
			$token = isset( $_COOKIE['str_portal_token'] ) ? (string) $_COOKIE['str_portal_token'] : '';
			if ( '' === $token ) return new WP_Error( 'str_portal_session_missing', 'Bitte melden Sie sich erneut mit Google an.', array( 'status' => 401 ) );
			$plan = sanitize_text_field( (string) $request->get_param( 'planCode' ) );
			$interval = sanitize_text_field( (string) $request->get_param( 'billingInterval' ) );
			if ( ! in_array( $plan, array( 'MANAGEMENT_INTERNAL', 'MANAGEMENT_MARKETPLACE' ), true ) || ! in_array( $interval, array( 'month', 'year' ), true ) ) return new WP_Error( 'str_plan_invalid', 'Ungültige Tarifauswahl.', array( 'status' => 400 ) );
			$result = self::api_json_request( '/billing/checkout-sessions', 'POST', array( 'planCode' => $plan, 'billingInterval' => $interval, 'successUrl' => home_url( '/portal/?zahlung=erfolgreich' ), 'cancelUrl' => home_url( '/portal/?zahlung=abgebrochen' ) ), $token );
			$url = esc_url_raw( (string) ( $result['checkoutUrl'] ?? '' ) );
			$host = wp_parse_url( $url, PHP_URL_HOST );
			if ( ! $url || 'https' !== wp_parse_url( $url, PHP_URL_SCHEME ) || ! is_string( $host ) || ! preg_match( '/(^|\.)stripe\.com$/i', $host ) ) return new WP_Error( 'str_checkout_failed', 'Der Stripe-Testcheckout konnte nicht gestartet werden.', array( 'status' => 502 ) );
			return rest_ensure_response( array( 'checkoutUrl' => $url, 'environment' => 'TEST' ) );
		} ) );
		register_rest_route( 'swisstoolrent/v1', '/support-cases', array( 'methods' => array( 'GET', 'POST' ), 'permission_callback' => static function () { return is_user_logged_in(); }, 'callback' => static function ( WP_REST_Request $request ) {
			$token = isset( $_COOKIE['str_portal_token'] ) ? (string) $_COOKIE['str_portal_token'] : '';
			if ( '' === $token ) return new WP_Error( 'str_portal_session_missing', 'Bitte melden Sie sich erneut mit Google an.', array( 'status' => 401 ) );
			$session = self::api_json_request( '/auth/session', 'GET', array(), $token );
			$organization_id = sanitize_text_field( (string) ( $session['actor']['organizationId'] ?? '' ) );
			if ( ! preg_match( '/^[0-9a-f-]{36}$/i', $organization_id ) ) return new WP_Error( 'str_support_context_missing', 'Organisationskontext fehlt.', array( 'status' => 401 ) );
			$path = '/organizations/' . rawurlencode( $organization_id ) . '/support-cases';
			if ( 'GET' === $request->get_method() ) return rest_ensure_response( self::api_json_request( $path, 'GET', array(), $token ) );
			$payload = array(
				'subjectType' => 'GENERAL',
				'category' => strtoupper( sanitize_key( (string) $request->get_param( 'category' ) ) ),
				'priority' => strtoupper( sanitize_key( (string) $request->get_param( 'priority' ) ) ),
				'title' => sanitize_text_field( (string) $request->get_param( 'title' ) ),
				'description' => sanitize_textarea_field( (string) $request->get_param( 'description' ) ),
			);
			return rest_ensure_response( self::api_json_request( $path, 'POST', $payload, $token, array( 'Idempotency-Key' => 'wp-support-' . wp_generate_uuid4() ) ) );
		} ) );
	}

	private static function api_json_request( string $path, string $method = 'GET', array $body = array(), string $bearer = '', array $extra_headers = array() ): array {
		$s = self::settings();
		$args = array( 'method' => $method, 'timeout' => 10, 'redirection' => 0, 'sslverify' => true, 'headers' => array_merge( array( 'Accept' => 'application/json', 'Content-Type' => 'application/json' ), $extra_headers ) );
		if ( '' !== $bearer ) $args['headers']['Authorization'] = 'Bearer ' . $bearer;
		if ( 'GET' !== $method ) $args['body'] = wp_json_encode( $body );
		$response = wp_remote_request( $s['api_base_url'] . '/' . ltrim( $path, '/' ), $args );
		if ( is_wp_error( $response ) ) return array( 'ok' => false, 'code' => 'backend_unreachable' );
		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $decoded ) ? $decoded : array( 'ok' => false, 'code' => 'invalid_response' );
	}

	public static function protect_customer_admin(): void {
		if ( is_admin() && ! wp_doing_ajax() && is_user_logged_in() && current_user_can( 'str_access_portal' ) && ! current_user_can( 'str_manage_platform' ) ) {
			wp_safe_redirect( home_url( '/portal/' ) );
			exit;
		}
	}

	public static function show_admin_bar( bool $show ): bool {
		return current_user_can( 'str_manage_platform' ) ? $show : false;
	}

	public static function render_setup(): void {
		self::require_platform_admin();
		$s = self::settings();
		$notice = sanitize_key( $_GET['str_notice'] ?? '' );
		?>
		<div class="wrap str-admin"><h1>SwissToolRent Einrichtung</h1><p class="str-lead">Verbinden Sie WordPress mit dem autoritativen SwissToolRent-Backend. Normale Kunden sehen diese technische Verwaltung nicht.</p>
		<?php if ( $notice ) : ?><div class="notice notice-<?php echo 'failed' === $notice ? 'error' : 'success'; ?> is-dismissible"><p><?php echo esc_html( self::notice_text( $notice ) ); ?></p></div><?php endif; ?>
		<div class="str-admin-grid"><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="str-admin-card"><input type="hidden" name="action" value="str_save_settings"><?php wp_nonce_field( 'str_save_settings' ); ?>
		<h2>1 Plattform und Kontakt</h2><?php self::field( 'Plattformname', 'platform_name', $s['platform_name'] ); ?><?php self::field( 'Betreiber', 'operator_name', $s['operator_name'] ); ?><?php self::field( 'Kontakt-E-Mail', 'contact_email', $s['contact_email'], 'email' ); ?>
		<h2>2 Backend und Updatekanal</h2><?php self::field( 'Backend-API', 'api_base_url', $s['api_base_url'], 'url', 'Nur HTTPS. Empfohlen: https://api.swisstoolrent.ch/v1' ); ?><?php self::field( 'API Client-ID', 'api_client_id', $s['api_client_id'] ); ?><?php self::field( 'Neues API-Secret', 'api_secret', '', 'password', get_option( self::SECRET_OPTION ) ? 'Ein Secret ist verschlüsselt hinterlegt. Nur zum Ersetzen ausfüllen.' : 'Wird verschlüsselt gespeichert und nie ausgegeben.', false ); ?><?php self::field( 'Plugin-Update-Manifest', 'update_manifest_url', $s['update_manifest_url'], 'url', 'Steuert kontrollierte, versionierte Plugin-Updates.' ); ?><?php self::field( 'Theme-Update-Manifest', 'theme_update_manifest_url', $s['theme_update_manifest_url'], 'url', 'Steuert kontrollierte, versionierte Theme-Updates.' ); ?>
		<h2>3 Google-Anmeldung</h2><?php self::field( 'Google Web Client-ID', 'google_client_id', $s['google_client_id'], 'text', 'Nur die öffentliche Client-ID. Ein Client-Secret bleibt ausschliesslich im Backend.' ); ?>
		<h2>4 Sprachen</h2><div class="str-checks"><?php foreach ( array( 'de-CH' => 'Deutsch', 'fr-CH' => 'Französisch', 'it-CH' => 'Italienisch', 'en' => 'Englisch' ) as $code => $label ) : ?><label><input type="checkbox" name="str[locales][]" value="<?php echo esc_attr( $code ); ?>" <?php checked( in_array( $code, $s['locales'], true ) ); ?>><?php echo esc_html( $label ); ?></label><?php endforeach; ?></div>
		<?php submit_button( 'Einrichtung speichern' ); ?></form>
		<aside class="str-admin-card"><h2>Systemcheck</h2><?php echo wp_kses_post( self::system_checks_html() ); ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="str_test_connection"><?php wp_nonce_field( 'str_test_connection' ); ?><?php submit_button( 'API-Verbindung testen', 'secondary' ); ?></form><p><a class="button" href="<?php echo esc_url( home_url( '/portal/' ) ); ?>">Portal öffnen</a></p></aside></div></div>
		<?php
	}

	public static function render_subscriptions(): void {
		self::require_platform_admin();
		$s = self::settings();
		?><div class="wrap str-admin"><h1>Abonnemente und Zugänge</h1><p class="str-lead">Bearbeiten Sie die sichtbaren Pilotpreise und Limits. Die produktive Freischaltung erfolgt ausschliesslich im Backend nach signiertem Stripe-Webhook und separater Freigabe.</p><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="str-admin-card"><input type="hidden" name="action" value="str_save_settings"><?php wp_nonce_field( 'str_save_settings' ); ?><div class="str-admin-grid">
		<?php foreach ( $s['subscription_plans'] as $code => $plan ) : ?><section><h2><?php echo esc_html( $plan['name'] ); ?></h2><p><code><?php echo esc_html( strtoupper( $code ) ); ?></code></p>
		<?php foreach ( array( 'name' => 'Tarifname', 'monthly' => 'Monatspreis CHF', 'yearly' => 'Jahrespreis CHF', 'trial_days' => 'Testtage', 'max_tools' => 'Max. Werkzeuge', 'max_members' => 'Max. Mitarbeitende' ) as $field => $label ) : ?><label class="str-field"><span><?php echo esc_html( $label ); ?></span><input type="<?php echo 'name' === $field ? 'text' : 'number'; ?>" min="0" name="str[subscription_plans][<?php echo esc_attr( $code ); ?>][<?php echo esc_attr( $field ); ?>]" value="<?php echo esc_attr( (string) $plan[ $field ] ); ?>"></label><?php endforeach; ?>
		<label class="str-field"><span>Status</span><select name="str[subscription_plans][<?php echo esc_attr( $code ); ?>][status]"><?php foreach ( array( 'DRAFT' => 'Entwurf', 'IN_REVIEW' => 'In Prüfung', 'PUBLISHED' => 'Veröffentlicht', 'PAUSED' => 'Pausiert' ) as $status => $label ) : ?><option value="<?php echo esc_attr( $status ); ?>" <?php selected( $plan['status'], $status ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label></section><?php endforeach; ?></div>
		<div class="str-state str-warning"><strong>Stop-Gate</strong><span>Preis- und Statusänderungen allein vergeben keine Backend-Rechte und aktivieren keinen Live-Zahlungsverkehr.</span></div><?php submit_button( 'Abo-Entwurf speichern' ); ?></form></div><?php
	}

	public static function render_users(): void {
		self::require_platform_admin(); ?>
		<div class="wrap str-admin str-user-admin">
			<h1>Benutzerverwaltung</h1><p class="str-lead">Registrierte Benutzer, Organisationen, Rollen und Zugänge zentral finden und verwalten. Sperren und Löschvorgänge werden revisionsfähig protokolliert.</p>
			<div class="str-admin-card str-user-toolbar"><label>Suche<input type="search" data-user-search placeholder="Name, E-Mail oder Firma"></label><label>Status<select data-user-state><option value="">Alle Status</option><option value="ACTIVE">Aktiv</option><option value="SUSPENDED">Gesperrt</option><option value="ARCHIVED">Archiviert</option></select></label><label>Abo<select data-user-plan><option value="">Alle Abos</option><option value="FREE">Kostenlos</option><option value="MANAGEMENT_INTERNAL">Tool Hub Intern</option><option value="MANAGEMENT_MARKETPLACE">Tool Hub Intern &amp; Extern</option></select></label><button class="button button-primary" type="button" data-user-refresh>Filtern</button></div>
			<div class="str-user-layout"><section class="str-admin-card"><div class="str-user-results" aria-live="polite"><p>Benutzer werden geladen …</p></div><div class="str-user-pagination"></div></section><aside class="str-admin-card str-user-detail"><h2>Benutzer auswählen</h2><p>Öffnen Sie links einen Datensatz, um Stammdaten, Rolle, Status und administrativen Abo-Zugang zu bearbeiten.</p></aside></div>
		</div><?php
	}

	public static function render_email_processes(): void {
		self::require_platform_admin();
		$processes = self::email_processes();
		?><div class="wrap str-admin"><h1>E-Mail-Leitbild und Portalprozesse</h1><div class="str-admin-card"><?php echo wp_kses_post( self::email_guideline_html() ); ?></div><div class="str-admin-card"><h2>Aktive Template-Vorschau</h2><?php echo wp_kses_post( self::render_email_template( 'Supportfall eröffnet', 'Ihr Anliegen wurde im SwissToolRent Support Hub aufgenommen.', 'Wir haben den Fall dem passenden Prozess zugeordnet. Bitte ergänzen Sie Nachweise, Antworten oder Rückfragen direkt im Portal, damit der Verlauf vollständig bleibt.', 'Supportfall öffnen', home_url( '/support-hub/' ) ) ); ?></div><div class="str-admin-card"><h2>Prozesskatalog</h2><p>Diese Ereignisse bilden den aktuellen Funktionsumfang von Konto, Tool Hub, Buchung, Zahlung, Versand, Kaution, Support und Administration ab. Produktive Anbieter bleiben an die ausgewiesenen Stop-Gates gebunden.</p><table class="widefat striped"><thead><tr><th>Phase</th><th>Ereignis</th><th>Auslöser</th><th>Empfänger</th><th>Betreff</th><th>CTA</th><th>Priorität</th></tr></thead><tbody><?php foreach ( $processes as $key => $item ) : ?><tr><td><?php echo esc_html( $item['phase'] ); ?></td><td><code><?php echo esc_html( $key ); ?></code></td><td><?php echo esc_html( $item['trigger'] ); ?></td><td><?php echo esc_html( $item['audience'] ); ?></td><td><?php echo esc_html( $item['subject'] ); ?></td><td><?php echo esc_html( $item['action'] ); ?></td><td><?php echo esc_html( $item['priority'] ); ?></td></tr><?php endforeach; ?></tbody></table></div></div><?php
	}

	public static function render_gates(): void {
		self::require_platform_admin();
		$s = self::settings();
		$labels = array( 'legal' => array( 'Recht', 'AGB, Verträge, Kaution, Gewährleistung und Einsprache' ), 'finance' => array( 'Finanzen', 'Preise, Provision, Steuer, Ledger und Provider' ), 'privacy' => array( 'Datenschutz', 'Bildanalyse, Aufbewahrung und Subprozessoren' ), 'operations' => array( 'Betrieb', 'Support, Monitoring, Backup und Wiederherstellung' ) );
		?><div class="wrap str-admin"><h1>Prüfungen und Freigaben</h1><p class="str-lead">Ein dokumentierter Status ersetzt keine fachliche Freigabe. Produktive Transaktionen bleiben bis zum separaten Stop-Gate deaktiviert.</p><div class="str-gates"><?php foreach ( $labels as $key => $label ) : ?><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="str-admin-card"><input type="hidden" name="action" value="str_save_gate"><input type="hidden" name="gate" value="<?php echo esc_attr( $key ); ?>"><?php wp_nonce_field( 'str_save_gate' ); ?><h2><?php echo esc_html( $label[0] ); ?></h2><p><?php echo esc_html( $label[1] ); ?></p><label>Status<select name="status"><option value="OPEN" <?php selected( $s['gates'][ $key ], 'OPEN' ); ?>>Offen</option><option value="IN_REVIEW" <?php selected( $s['gates'][ $key ], 'IN_REVIEW' ); ?>>In Prüfung</option><option value="APPROVED" <?php selected( $s['gates'][ $key ], 'APPROVED' ); ?>>Freigegeben</option></select></label><?php submit_button( 'Status dokumentieren', 'secondary' ); ?></form><?php endforeach; ?></div></div><?php
	}

	public static function render_status(): void {
		self::require_platform_admin();
		?><div class="wrap str-admin"><h1>SwissToolRent Systemstatus</h1><?php echo wp_kses_post( self::system_checks_html() ); ?><p><strong>Hinweis:</strong> WordPress kommuniziert nur über HTTPS-APIs. PostgreSQL, Worker und Object Storage werden niemals direkt verbunden.</p></div><?php
	}

	private static function system_checks_html(): string {
		$s = self::settings();
		$api = self::api_request( '/health' );
		$checks = array( 'WordPress und PHP' => version_compare( PHP_VERSION, '8.1', '>=' ), 'HTTPS-Website' => is_ssl(), 'Backend-API' => $api['ok'], 'API-Secret geschützt' => function_exists( 'openssl_encrypt' ), 'Pflichtseiten vorhanden' => (bool) get_page_by_path( 'portal' ) && (bool) get_page_by_path( 'tool-hub' ) );
		$html = '<div class="str-check-list">';
		foreach ( $checks as $label => $ok ) {
			$html .= '<div class="str-state ' . ( $ok ? 'str-ok' : 'str-warning' ) . '"><strong>' . esc_html( $label ) . '</strong><span>' . ( $ok ? 'OK' : 'Prüfung erforderlich' ) . '</span></div>';
		}
		$approved = count( array_filter( $s['gates'], static fn( $status ) => 'APPROVED' === $status ) );
		return $html . '<div class="str-state str-warning"><strong>Produktionsfreigaben</strong><span>' . esc_html( $approved . ' von 4 dokumentiert; Produktivmodus gesperrt' ) . '</span></div></div>';
	}

	private static function field( string $label, string $name, string $value, string $type = 'text', string $help = '', bool $nested = true ): void {
		$field_name = $nested ? 'str[' . $name . ']' : $name;
		echo '<label class="str-field"><span>' . esc_html( $label ) . '</span><input type="' . esc_attr( $type ) . '" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $value ) . '" autocomplete="off">';
		if ( $help ) {
			echo '<small>' . esc_html( $help ) . '</small>';
		}
		echo '</label>';
	}

	private static function require_platform_admin(): void {
		if ( ! current_user_can( 'str_manage_platform' ) ) {
			wp_die( esc_html__( 'Keine Berechtigung.', 'swisstoolrent-core' ), '', array( 'response' => 403 ) );
		}
	}

	private static function notice_text( string $notice ): string {
		return array( 'saved' => 'Einstellungen gespeichert.', 'connected' => 'Backend-Verbindung erfolgreich getestet.', 'failed' => 'Backend-Verbindung fehlgeschlagen. URL, Zertifikat und Tunnel prüfen.', 'gate-saved' => 'Prüfstatus dokumentiert.' )[ $notice ] ?? 'Status aktualisiert.';
	}

	public static function check_plugin_update( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}
		$s = self::settings();
		$response = wp_remote_get( $s['update_manifest_url'], array( 'timeout' => 5, 'redirection' => 0, 'sslverify' => true ) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return $transient;
		}
		$manifest = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $manifest ) || empty( $manifest['version'] ) || empty( $manifest['package'] ) || version_compare( STR_CORE_VERSION, $manifest['version'], '>=' ) ) {
			unset( $transient->response[ plugin_basename( __FILE__ ) ] );
			return $transient;
		}
		if ( 'https' !== wp_parse_url( $manifest['package'], PHP_URL_SCHEME ) ) {
			return $transient;
		}
		$transient->response[ plugin_basename( __FILE__ ) ] = (object) array( 'slug' => 'swisstoolrent-core', 'plugin' => plugin_basename( __FILE__ ), 'new_version' => sanitize_text_field( $manifest['version'] ), 'url' => esc_url_raw( $manifest['homepage'] ?? 'https://www.swisstoolrent.ch/' ), 'package' => esc_url_raw( $manifest['package'] ), 'tested' => sanitize_text_field( $manifest['tested'] ?? '' ), 'requires_php' => sanitize_text_field( $manifest['requires_php'] ?? '8.1' ) );
		return $transient;
	}

	public static function check_theme_update( $transient ) {
		if ( empty( $transient->checked ) || ! isset( $transient->checked['swisstoolrent'] ) ) {
			return $transient;
		}
		$s = self::settings();
		$response = wp_remote_get( $s['theme_update_manifest_url'], array( 'timeout' => 5, 'redirection' => 0, 'sslverify' => true ) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return $transient;
		}
		$manifest = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $manifest ) || empty( $manifest['version'] ) || empty( $manifest['package'] ) || version_compare( (string) $transient->checked['swisstoolrent'], $manifest['version'], '>=' ) ) {
			unset( $transient->response['swisstoolrent'] );
			return $transient;
		}
		if ( 'https' !== wp_parse_url( $manifest['package'], PHP_URL_SCHEME ) ) {
			return $transient;
		}
		$transient->response['swisstoolrent'] = array(
			'theme' => 'swisstoolrent',
			'new_version' => sanitize_text_field( $manifest['version'] ),
			'url' => esc_url_raw( $manifest['homepage'] ?? 'https://www.swisstoolrent.ch/' ),
			'package' => esc_url_raw( $manifest['package'] ),
			'requires_php' => sanitize_text_field( $manifest['requires_php'] ?? '8.1' ),
		);
		return $transient;
	}
}

register_activation_hook( __FILE__, array( SwissToolRent_Core::class, 'activate' ) );
register_deactivation_hook( __FILE__, array( SwissToolRent_Core::class, 'deactivate' ) );
SwissToolRent_Core::boot();
