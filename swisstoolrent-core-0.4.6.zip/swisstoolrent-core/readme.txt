=== SwissToolRent Core ===
Contributors: swisstoolrent
Tags: tool rental, portal, api, roles
Requires at least: 6.6
Tested up to: 6.8
Requires PHP: 8.1
Stable tag: 0.4.5
License: GPLv2 or later

Verbindet das SwissToolRent-WordPress-Frontend mit dem autoritativen Backend.

== Description ==

SwissToolRent Core richtet Portal-Seiten und Rollen ein, schützt technische
Einstellungen über Capabilities, speichert das API-Secret verschlüsselt und
prüft die Backend-Verbindung ausschliesslich über HTTPS.

Zahlung, Versandlabel, Kautionseinzug und andere produktive Transaktionen
werden durch dieses Vorabpaket nicht aktiviert.

== Installation ==

1. ZIP in WordPress unter Plugins > Installieren > Plugin hochladen installieren.
2. Plugin aktivieren.
3. Unter SwissToolRent > Einrichtung die HTTPS-Backend-URL konfigurieren.
4. Verbindung testen und offene Freigaben dokumentieren.

== Changelog ==

= 0.4.5 =
* Öffentliche Navigation, Produktbereiche, Über-uns-Fläche und Kontaktformular
  für den Pilotauftritt ergänzt.
* Rollengetrennte Portalnavigation und Mein-Bereich-Zugang geschärft.

= 0.1.0 =
* Erste installierbare Architekturgrundlage mit Rollen, Setup, Systemstatus,
  Pflichtseiten, Freigabegates und kontrolliertem Updatekanal.
